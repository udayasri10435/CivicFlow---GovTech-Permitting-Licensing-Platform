export type UserRole = 
  | 'citizen'          // Homeowner / Licensed General Contractor
  | 'permit_tech'      // Intake & Completeness Reviewer
  | 'plan_reviewer'    // Departmental Plans Examiner (Building, Zoning, Fire, Eng)
  | 'field_inspector'  // Building & Safety Field Inspector
  | 'city_admin';      // Chief Building Official / Director

export type PermitStatus = 
  | 'draft'
  | 'submitted'
  | 'under_review'
  | 'corrections_required'
  | 'ready_for_payment'
  | 'issued'
  | 'inspections_active'
  | 'final_approved'
  | 'closed';

export type PermitType = 
  | 'residential_new'
  | 'residential_alteration'
  | 'commercial_ti'
  | 'adu_addition'
  | 'solar_pv_storage'
  | 'electrical_service'
  | 'plumbing_mechanical'
  | 'right_of_way';

export type DepartmentType = 'zoning' | 'building' | 'fire' | 'public_works';

export interface DepartmentReview {
  department: DepartmentType;
  name: string;
  reviewer: string;
  status: 'pending' | 'in_review' | 'approved' | 'revisions_requested';
  assignedDate: string;
  completedDate?: string;
  comments?: string;
  conditions?: string[];
  codeCitations?: string[];
}

export interface FeeItem {
  id: string;
  name: string;
  category: 'plan_check' | 'permit_fee' | 'impact_fee' | 'technology_surcharge' | 'inspection_fee';
  amount: number;
  status: 'unpaid' | 'paid';
  paidDate?: string;
}

export interface BlueprintMarkup {
  id: string;
  xPercent: number;
  yPercent: number;
  sheet: string;
  author: string;
  department: DepartmentType;
  comment: string;
  status: 'open' | 'resolved';
  codeCitation?: string;
  timestamp: string;
}

export interface InspectionChecklistItem {
  id: string;
  label: string;
  codeRef: string;
  status: 'pass' | 'fail' | 'na' | 'pending';
  notes?: string;
}

export interface InspectionRecord {
  id: string;
  permitId: string;
  type: string; // e.g. "Footing / Foundation", "Rough Framing", "Rough MEP", "Insulation", "Final Building"
  scheduledDate: string;
  timeWindow: 'AM (8:00 - 12:00)' | 'PM (12:00 - 4:00)';
  inspectorName: string;
  status: 'scheduled' | 'passed' | 'failed' | 'conditional_pass';
  completedDate?: string;
  notes?: string;
  checklist?: InspectionChecklistItem[];
  deficiencies?: string[];
  siteContact: {
    name: string;
    phone: string;
  };
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  author: string;
  action: string;
  details?: string;
}

export interface ParcelInfo {
  apn: string; // e.g. "042-180-22"
  address: string;
  owner: string;
  zoning: 'R-1' | 'R-3' | 'C-2' | 'M-1';
  zoningDescription: string;
  lotSizeSqFt: number;
  floodZone: 'Zone X (Minimal)' | 'Zone AE (100-Year)' | 'None';
  historicDistrict: boolean;
  maxHeightFt: number;
  setbacks: {
    front: number;
    rear: number;
    side: number;
  };
  activePermitCount: number;
}

export interface PermitApplication {
  id: string; // e.g. "PRMT-2026-0842"
  type: PermitType;
  title: string;
  applicant: {
    name: string;
    role: 'homeowner' | 'contractor';
    company?: string;
    licenseNumber?: string;
    phone: string;
    email: string;
  };
  property: {
    address: string;
    apn: string;
    zoning: string;
    lotSizeSqFt: number;
  };
  projectScope: {
    description: string;
    squareFootage: number;
    estimatedValuation: number;
    stories: number;
    occupancyGroup: string;
    constructionType: string;
  };
  status: PermitStatus;
  submittedDate: string;
  targetCompletionDate: string;
  daysInReview: number;
  departmentReviews: DepartmentReview[];
  fees: FeeItem[];
  markups: BlueprintMarkup[];
  inspections: InspectionRecord[];
  timeline: TimelineEvent[];
  documents: {
    id: string;
    name: string;
    type: 'architectural' | 'structural' | 'site_plan' | 'energy_calc' | 'contractor_license';
    size: string;
    uploadDate: string;
    version: number;
  }[];
  issuedDate?: string;
  expirationDate?: string;
  conditionsOfApproval?: string[];
}
