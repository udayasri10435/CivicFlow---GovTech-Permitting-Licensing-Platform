/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MunicipalHeader } from './components/common/MunicipalHeader';
import { CitizenPortal } from './components/citizen/CitizenPortal';
import { MunicipalWorkflowQueue } from './components/workflow/MunicipalWorkflowQueue';
import { InspectionManagement } from './components/inspections/InspectionManagement';
import { GisParcelExplorer } from './components/gis/GisParcelExplorer';
import { MunicipalAnalytics } from './components/analytics/MunicipalAnalytics';
import { OfficialPermitCertificate } from './components/permit/OfficialPermitCertificate';
import { BlueprintViewer } from './components/workflow/BlueprintViewer';
import { INITIAL_PERMITS } from './data/mockMunicipalData';
import { PermitApplication, UserRole, InspectionRecord, ParcelInfo } from './types/permits';
import { Landmark, Shield, X, Eye } from 'lucide-react';

export default function App() {
  // Navigation & Role State
  const [currentTab, setCurrentTab] = useState<'citizen' | 'workflow' | 'inspections' | 'gis' | 'analytics'>('citizen');
  const [activeRole, setActiveRole] = useState<UserRole>('citizen');

  // Permits dataset state with localStorage initialization
  const [permits, setPermits] = useState<PermitApplication[]>(() => {
    try {
      const saved = localStorage.getItem('civicflow_permits_data');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load permits from localStorage', e);
    }
    return INITIAL_PERMITS;
  });

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('civicflow_permits_data', JSON.stringify(permits));
    } catch (e) {
      console.error('Failed to save permits to localStorage', e);
    }
  }, [permits]);

  // Modal states
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [viewingCertificatePermit, setViewingCertificatePermit] = useState<PermitApplication | null>(null);
  const [viewingPlanRoomPermit, setViewingPlanRoomPermit] = useState<PermitApplication | null>(null);
  const [targetWorkflowPermitId, setTargetWorkflowPermitId] = useState<string | null>(null);

  // Actions
  const handleAddNewPermit = (newPermit: PermitApplication) => {
    setPermits([newPermit, ...permits]);
  };

  const handleUpdatePermit = (updatedPermit: PermitApplication) => {
    setPermits(permits.map((p) => (p.id === updatedPermit.id ? updatedPermit : p)));
    if (viewingPlanRoomPermit?.id === updatedPermit.id) {
      setViewingPlanRoomPermit(updatedPermit);
    }
  };

  const handlePayFees = (permitId: string) => {
    setPermits(
      permits.map((p) => {
        if (p.id === permitId) {
          const updatedFees = p.fees.map((f) => ({
            ...f,
            status: 'paid' as const,
            paidDate: new Date().toISOString().split('T')[0],
          }));

          return {
            ...p,
            status: 'issued',
            fees: updatedFees,
            issuedDate: new Date().toISOString().split('T')[0],
            expirationDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            timeline: [
              ...p.timeline,
              {
                id: `tl-pay-${Date.now()}`,
                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                author: 'Permittee (Online Portal)',
                action: 'Permit Fees Paid & Permit Issued',
                details: 'Payment recorded via Municipal Payment Gateway. Construction authorized.',
              },
            ],
          };
        }
        return p;
      })
    );
  };

  const handleScheduleInspection = (inspectionData: Omit<InspectionRecord, 'id' | 'status'>) => {
    const newRecord: InspectionRecord = {
      ...inspectionData,
      id: `insp-${Math.floor(100 + Math.random() * 900)}`,
      status: 'scheduled',
    };

    setPermits(
      permits.map((p) => {
        if (p.id === inspectionData.permitId) {
          return {
            ...p,
            status: p.status === 'issued' ? 'inspections_active' : p.status,
            inspections: [...p.inspections, newRecord],
            timeline: [
              ...p.timeline,
              {
                id: `tl-insp-${Date.now()}`,
                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                author: inspectionData.siteContact.name,
                action: `Inspection Scheduled: ${inspectionData.type}`,
                details: `Requested for ${inspectionData.scheduledDate} (${inspectionData.timeWindow})`,
              },
            ],
          };
        }
        return p;
      })
    );
  };

  const handleUpdateInspection = (permitId: string, updatedRecord: InspectionRecord) => {
    setPermits(
      permits.map((p) => {
        if (p.id === permitId) {
          const updatedInspections = p.inspections.map((i) =>
            i.id === updatedRecord.id ? updatedRecord : i
          );

          // If final building passed, mark permit final approved
          const isFinalPassed = updatedRecord.status === 'passed' && updatedRecord.type.toLowerCase().includes('final');

          return {
            ...p,
            status: isFinalPassed ? 'final_approved' : p.status,
            inspections: updatedInspections,
            timeline: [
              ...p.timeline,
              {
                id: `tl-insp-res-${Date.now()}`,
                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                author: updatedRecord.inspectorName,
                action: `Inspection Result: ${updatedRecord.type} (${updatedRecord.status.toUpperCase()})`,
                details: updatedRecord.notes,
              },
            ],
          };
        }
        return p;
      })
    );
  };

  const handleSelectParcelToApply = (parcel: ParcelInfo) => {
    setCurrentTab('citizen');
    setIsWizardOpen(true);
  };

  const handleViewPermitInWorkflow = (permitId: string) => {
    setTargetWorkflowPermitId(permitId);
    setCurrentTab('workflow');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* 3-Zone Municipal Top Bar */}
      <MunicipalHeader
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        activeRole={activeRole}
        onRoleChange={setActiveRole}
        onStartNewApplication={() => {
          setCurrentTab('citizen');
          setIsWizardOpen(true);
        }}
      />

      {/* Main Viewport Content */}
      <main className="flex-1">
        {currentTab === 'citizen' && (
          <CitizenPortal
            permits={permits}
            onAddNewPermit={handleAddNewPermit}
            onPayFees={handlePayFees}
            onScheduleInspection={handleScheduleInspection}
            onViewCertificate={setViewingCertificatePermit}
            onViewPlanReview={setViewingPlanRoomPermit}
            isWizardOpen={isWizardOpen}
            onOpenWizard={() => setIsWizardOpen(true)}
            onCloseWizard={() => setIsWizardOpen(false)}
          />
        )}

        {currentTab === 'workflow' && (
          <MunicipalWorkflowQueue
            permits={permits}
            activeRole={activeRole}
            onUpdatePermit={handleUpdatePermit}
            onViewCertificate={setViewingCertificatePermit}
            selectedPermitId={targetWorkflowPermitId}
            onSelectPermitId={setTargetWorkflowPermitId}
          />
        )}

        {currentTab === 'inspections' && (
          <InspectionManagement
            permits={permits}
            onUpdateInspection={handleUpdateInspection}
            onViewCertificate={setViewingCertificatePermit}
          />
        )}

        {currentTab === 'gis' && (
          <GisParcelExplorer
            permits={permits}
            onSelectParcelToApply={handleSelectParcelToApply}
            onViewPermit={handleViewPermitInWorkflow}
          />
        )}

        {currentTab === 'analytics' && (
          <MunicipalAnalytics permits={permits} />
        )}
      </main>

      {/* Official Permit Certificate Modal */}
      {viewingCertificatePermit && (
        <OfficialPermitCertificate
          permit={viewingCertificatePermit}
          onClose={() => setViewingCertificatePermit(null)}
        />
      )}

      {/* Plan Room Blueprint Viewer Modal (when opened from Citizen Portal) */}
      {viewingPlanRoomPermit && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-5xl w-full my-8 overflow-hidden shadow-2xl text-slate-100">
            <div className="px-6 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-blue-400 font-semibold uppercase tracking-wider">
                  Citizen Plan Room & Redlines
                </div>
                <h3 className="text-base font-bold">
                  {viewingPlanRoomPermit.id} · {viewingPlanRoomPermit.title}
                </h3>
              </div>
              <button
                onClick={() => setViewingPlanRoomPermit(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <BlueprintViewer
                markups={viewingPlanRoomPermit.markups}
                onAddMarkup={(m) => {
                  const newM = {
                    ...m,
                    id: `mk-${Date.now()}`,
                    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                  };
                  handleUpdatePermit({
                    ...viewingPlanRoomPermit,
                    markups: [...viewingPlanRoomPermit.markups, newM],
                  });
                }}
                onResolveMarkup={(id) => {
                  handleUpdatePermit({
                    ...viewingPlanRoomPermit,
                    markups: viewingPlanRoomPermit.markups.map((m) =>
                      m.id === id ? { ...m, status: 'resolved' as const } : m
                    ),
                  });
                }}
                readOnly={activeRole === 'citizen'}
              />

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setViewingPlanRoomPermit(null)}
                  className="px-4 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded transition-colors"
                >
                  Close Plan Room
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quiet Municipal Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Landmark className="w-4 h-4 text-slate-400" />
            <span className="font-semibold text-slate-800">City of Oakridge, California</span>
            <span>·</span>
            <span>Community Development & Building Safety Division</span>
          </div>

          <div className="flex items-center gap-6">
            <span>Building Codes: IBC 2024 / CRC / Title 24</span>
            <span>·</span>
            <span>Inspection Hotline: (555) 392-4800</span>
            <span>·</span>
            <span className="font-mono">CivicFlow Enterprise Permitting</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
