import React, { useState } from 'react';
import { UserRole } from '../../types/permits';
import { ShieldCheck, UserCheck, ChevronDown, Landmark, FileText, CheckCircle2 } from 'lucide-react';

interface MunicipalHeaderProps {
  currentTab: 'citizen' | 'workflow' | 'inspections' | 'gis' | 'analytics';
  onSelectTab: (tab: 'citizen' | 'workflow' | 'inspections' | 'gis' | 'analytics') => void;
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onStartNewApplication: () => void;
}

export const MunicipalHeader: React.FC<MunicipalHeaderProps> = ({
  currentTab,
  onSelectTab,
  activeRole,
  onRoleChange,
  onStartNewApplication,
}) => {
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const roles: { id: UserRole; label: string; department: string }[] = [
    { id: 'citizen', label: 'Citizen & Contractor', department: 'Public Citizen Portal' },
    { id: 'permit_tech', label: 'Permit Technician', department: 'Intake & Cashiering' },
    { id: 'plan_reviewer', label: 'Plans Examiner', department: 'Building & Zoning Review' },
    { id: 'field_inspector', label: 'Field Building Inspector', department: 'Building & Safety Field Div.' },
    { id: 'city_admin', label: 'Chief Building Official / Director', department: 'Executive Governance' },
  ];

  const currentRoleObj = roles.find((r) => r.id === activeRole) || roles[0];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* City Civic Header Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs px-6 py-1.5 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Landmark className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-medium text-slate-200">City of Oakridge</span>
          <span className="text-slate-500">·</span>
          <span>Community Development & Building Safety Department</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-slate-400">
          <span>Municipal Code IBC 2024 / OMC Title 17</span>
          <span>·</span>
          <span className="text-emerald-400 font-medium">GIS Server Online</span>
        </div>
      </div>

      {/* Strict 3-Zone Top Navigation Contract */}
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onSelectTab('citizen');
            }}
            className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2"
          >
            <span className="w-8 h-8 rounded bg-blue-600 text-white flex items-center justify-center font-black text-sm">
              CF
            </span>
            <span>CivicFlow</span>
          </a>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          <button
            onClick={() => onSelectTab('citizen')}
            className={`transition-colors text-left hover:text-slate-900 ${
              currentTab === 'citizen'
                ? 'text-blue-700 font-semibold border-b-2 border-blue-600 py-4 -mb-[2px]'
                : 'py-4'
            }`}
          >
            Citizen Portal
          </button>
          <button
            onClick={() => onSelectTab('workflow')}
            className={`transition-colors text-left hover:text-slate-900 ${
              currentTab === 'workflow'
                ? 'text-blue-700 font-semibold border-b-2 border-blue-600 py-4 -mb-[2px]'
                : 'py-4'
            }`}
          >
            Plan Review Workflow
          </button>
          <button
            onClick={() => onSelectTab('inspections')}
            className={`transition-colors text-left hover:text-slate-900 ${
              currentTab === 'inspections'
                ? 'text-blue-700 font-semibold border-b-2 border-blue-600 py-4 -mb-[2px]'
                : 'py-4'
            }`}
          >
            Field Inspections
          </button>
          <button
            onClick={() => onSelectTab('gis')}
            className={`transition-colors text-left hover:text-slate-900 ${
              currentTab === 'gis'
                ? 'text-blue-700 font-semibold border-b-2 border-blue-600 py-4 -mb-[2px]'
                : 'py-4'
            }`}
          >
            GIS & Parcel Map
          </button>
          <button
            onClick={() => onSelectTab('analytics')}
            className={`transition-colors text-left hover:text-slate-900 ${
              currentTab === 'analytics'
                ? 'text-blue-700 font-semibold border-b-2 border-blue-600 py-4 -mb-[2px]'
                : 'py-4'
            }`}
          >
            Municipal Analytics
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* Active Role Selector dropdown */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors border border-slate-200"
              title="Switch Municipal Persona / Role"
            >
              <UserCheck className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden lg:inline text-slate-500 font-normal">Role:</span>
              <span className="font-semibold text-slate-900">{currentRoleObj.label}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {roleMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg border border-slate-200 py-1 z-50">
                <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  Select Municipal Viewport
                </div>
                {roles.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      onRoleChange(r.id);
                      setRoleMenuOpen(false);
                      if (r.id === 'citizen') onSelectTab('citizen');
                      else if (r.id === 'field_inspector') onSelectTab('inspections');
                      else if (r.id === 'plan_reviewer' || r.id === 'permit_tech') onSelectTab('workflow');
                      else if (r.id === 'city_admin') onSelectTab('analytics');
                    }}
                    className={`w-full text-left px-3 py-2.5 text-xs flex items-start gap-2 hover:bg-slate-50 transition-colors ${
                      activeRole === r.id ? 'bg-blue-50/60 font-semibold text-blue-900' : 'text-slate-700'
                    }`}
                  >
                    <div className="mt-0.5">
                      {activeRole === r.id ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      ) : (
                        <div className="w-3.5 h-3.5 rounded-full border border-slate-300" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium text-slate-900">{r.label}</div>
                      <div className="text-[11px] text-slate-500">{r.department}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Primary Action Button */}
          <button
            onClick={onStartNewApplication}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded hover:bg-blue-700 transition-colors whitespace-nowrap shadow-sm flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Apply for Permit</span>
          </button>
        </div>
      </div>

      {/* Mobile nav row */}
      <div className="md:hidden flex items-center overflow-x-auto px-4 py-2 border-t border-slate-100 text-xs gap-4 text-slate-600">
        <button
          onClick={() => onSelectTab('citizen')}
          className={`whitespace-nowrap ${currentTab === 'citizen' ? 'font-bold text-blue-600' : ''}`}
        >
          Citizen Portal
        </button>
        <button
          onClick={() => onSelectTab('workflow')}
          className={`whitespace-nowrap ${currentTab === 'workflow' ? 'font-bold text-blue-600' : ''}`}
        >
          Plan Review
        </button>
        <button
          onClick={() => onSelectTab('inspections')}
          className={`whitespace-nowrap ${currentTab === 'inspections' ? 'font-bold text-blue-600' : ''}`}
        >
          Inspections
        </button>
        <button
          onClick={() => onSelectTab('gis')}
          className={`whitespace-nowrap ${currentTab === 'gis' ? 'font-bold text-blue-600' : ''}`}
        >
          GIS Map
        </button>
        <button
          onClick={() => onSelectTab('analytics')}
          className={`whitespace-nowrap ${currentTab === 'analytics' ? 'font-bold text-blue-600' : ''}`}
        >
          Analytics
        </button>
      </div>
    </header>
  );
};
