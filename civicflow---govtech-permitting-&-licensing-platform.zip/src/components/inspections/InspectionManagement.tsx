import React, { useState } from 'react';
import { PermitApplication, InspectionRecord, InspectionChecklistItem } from '../../types/permits';
import { 
  HardHat, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  MapPin, 
  Phone, 
  User, 
  FileText, 
  Camera, 
  Check, 
  ChevronRight,
  ClipboardList,
  X
} from 'lucide-react';

interface InspectionManagementProps {
  permits: PermitApplication[];
  onUpdateInspection: (permitId: string, updatedRecord: InspectionRecord) => void;
  onViewCertificate: (permit: PermitApplication) => void;
}

export const InspectionManagement: React.FC<InspectionManagementProps> = ({
  permits,
  onUpdateInspection,
  onViewCertificate,
}) => {
  // Aggregate all inspections across permits
  const allInspections = permits.flatMap((p) =>
    p.inspections.map((i) => ({
      ...i,
      permit: p,
    }))
  );

  const [activeDateFilter, setActiveDateFilter] = useState<string>('2026-09-29');
  const [selectedInspectionItem, setSelectedInspectionItem] = useState<{
    record: InspectionRecord;
    permit: PermitApplication;
  } | null>(allInspections.length > 0 ? { record: allInspections[0], permit: allInspections[0].permit } : null);

  // Active checklist modal state for field inspector
  const [checklistModalOpen, setChecklistModalOpen] = useState(false);
  const [activeChecklist, setActiveChecklist] = useState<InspectionChecklistItem[]>([]);
  const [inspectorNotes, setInspectorNotes] = useState('');
  const [selectedResult, setSelectedResult] = useState<'passed' | 'failed' | 'conditional_pass'>('passed');

  const openInspectionTerminal = (rec: InspectionRecord, permit: PermitApplication) => {
    setSelectedInspectionItem({ record: rec, permit });
    setActiveChecklist(
      rec.checklist || [
        { id: 'c-1', label: 'Point load posts aligned with footing pads', codeRef: 'IRC R602.7', status: 'pass' },
        { id: 'c-2', label: 'Shear wall nailing (8d common @ 4" boundary, 12" field)', codeRef: 'IRC R602.10', status: 'pass' },
        { id: 'c-3', label: 'Electrical wire nail plates installed on studs < 1.25" from edge', codeRef: 'NEC 300.4', status: 'pass' },
        { id: 'c-4', label: 'Plumbing DWV test hold and pipe slope', codeRef: 'CPC 704.1', status: 'pass' },
        { id: 'c-5', label: 'Fire blocking complete at floor and ceiling lines', codeRef: 'IRC R302.11', status: 'pass' },
      ]
    );
    setInspectorNotes(rec.notes || '');
    setSelectedResult(rec.status === 'scheduled' ? 'passed' : (rec.status as any));
    setChecklistModalOpen(true);
  };

  const handleToggleChecklistStatus = (itemId: string, newStatus: 'pass' | 'fail' | 'na') => {
    setActiveChecklist(
      activeChecklist.map((item) => (item.id === itemId ? { ...item, status: newStatus } : item))
    );
  };

  const handleCompleteInspection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInspectionItem) return;

    const updatedRecord: InspectionRecord = {
      ...selectedInspectionItem.record,
      status: selectedResult,
      completedDate: `${new Date().toISOString().split('T')[0]} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      notes: inspectorNotes,
      checklist: activeChecklist,
    };

    onUpdateInspection(selectedInspectionItem.permit.id, updatedRecord);
    setChecklistModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Field Inspection Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="text-xs text-blue-600 font-semibold uppercase tracking-wider">
            City of Oakridge Building & Safety Division
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Field Inspection Dispatch & Digital Job Terminal
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Inspector Bob Martinez, ICC Certified #412 · Daily Route & Code Compliance Checklists
          </p>
        </div>

        {/* Date / Today selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-500 ml-1" />
            <button
              onClick={() => setActiveDateFilter('2026-09-29')}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                activeDateFilter === '2026-09-29'
                  ? 'bg-white text-slate-900 font-bold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Today (Sept 29)
            </button>
            <button
              onClick={() => setActiveDateFilter('all')}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                activeDateFilter === 'all'
                  ? 'bg-white text-slate-900 font-bold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Inspections ({allInspections.length})
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Daily Route on Left / Inspection Terminal Details on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Route List (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-600 font-medium">
            <span>Assigned Stops ({allInspections.length})</span>
            <span className="font-mono">Zone 1: West Oakridge</span>
          </div>

          <div className="space-y-3">
            {allInspections.map(({ permit, ...record }) => {
              const isSelected = selectedInspectionItem?.record.id === record.id;
              const isPassed = record.status === 'passed';
              const isScheduled = record.status === 'scheduled';
              const isFailed = record.status === 'failed';

              return (
                <div
                  key={record.id}
                  onClick={() => setSelectedInspectionItem({ record, permit })}
                  className={`p-4 rounded-xl border cursor-pointer transition-all text-xs bg-white shadow-sm ${
                    isSelected
                      ? 'border-blue-600 ring-2 ring-blue-500/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="font-mono font-bold text-slate-900">{record.timeWindow}</span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider ${
                        isPassed
                          ? 'text-emerald-700'
                          : isFailed
                          ? 'text-rose-700'
                          : 'text-blue-700 animate-pulse'
                      }`}
                    >
                      {record.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="mt-2">
                    <h3 className="font-bold text-slate-900 text-sm">{record.type}</h3>
                    <div className="text-slate-600 mt-1 flex items-center gap-1 font-mono text-[11px]">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{permit.property.address}</span>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-[11px] pt-2 border-t border-slate-100 text-slate-500">
                    <span>Permit: <strong className="font-mono text-slate-700">{permit.id}</strong></span>
                    <span>Contact: {record.siteContact.name}</span>
                  </div>
                </div>
              );
            })}

            {allInspections.length === 0 && (
              <div className="p-8 bg-white border border-slate-200 rounded-xl text-center text-xs text-slate-500">
                No inspections currently assigned for this date.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Selected Inspection Detail / Terminal (7 cols) */}
        {selectedInspectionItem ? (
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <div className="text-[11px] font-mono text-slate-500 uppercase">
                  Inspection Ticket #{selectedInspectionItem.record.id}
                </div>
                <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                  {selectedInspectionItem.record.type}
                </h2>
                <div className="text-xs text-slate-600 mt-0.5">
                  {selectedInspectionItem.permit.property.address}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onViewCertificate(selectedInspectionItem.permit)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                >
                  View Job Card
                </button>
                <button
                  onClick={() => openInspectionTerminal(selectedInspectionItem.record, selectedInspectionItem.permit)}
                  className="px-4 py-1.5 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors shadow-sm flex items-center gap-1.5"
                >
                  <ClipboardList className="w-3.5 h-3.5" />
                  <span>Open Code Checklist</span>
                </button>
              </div>
            </div>

            {/* Quick Contact & Access Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs">
              <div className="space-y-1">
                <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>On-Site Superintendent / Contact</span>
                </div>
                <div className="text-slate-900 font-medium">{selectedInspectionItem.record.siteContact.name}</div>
                <div className="text-slate-600 font-mono flex items-center gap-1.5">
                  <Phone className="w-3 h-3 text-blue-600" />
                  <span>{selectedInspectionItem.record.siteContact.phone}</span>
                </div>
              </div>

              <div className="space-y-1">
                <div className="font-semibold text-slate-800">Job Site Access Notes</div>
                <div className="text-slate-700 italic">
                  {selectedInspectionItem.record.notes || 'No special access instructions entered.'}
                </div>
              </div>
            </div>

            {/* Previous Inspection History on this Permit */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3">
                Inspection Phase History on Permit {selectedInspectionItem.permit.id}
              </h3>

              <div className="space-y-2">
                {selectedInspectionItem.permit.inspections.map((insp) => (
                  <div
                    key={insp.id}
                    className="p-3 rounded-lg border border-slate-200 bg-white flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{insp.type}</div>
                      <div className="text-slate-500 font-mono text-[11px]">
                        {insp.scheduledDate} · {insp.timeWindow} · {insp.inspectorName}
                      </div>
                      {insp.notes && <div className="text-[11px] text-slate-600 mt-1">"{insp.notes}"</div>}
                    </div>

                    <span
                      className={`text-xs font-bold uppercase ${
                        insp.status === 'passed'
                          ? 'text-emerald-700'
                          : insp.status === 'failed'
                          ? 'text-rose-700'
                          : 'text-blue-700'
                      }`}
                    >
                      {insp.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </div>

      {/* Field Inspection Checklist Modal */}
      {checklistModalOpen && selectedInspectionItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full my-8 overflow-hidden text-slate-900">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-blue-400 font-semibold uppercase tracking-wider">
                  City of Oakridge Mobile Inspector Terminal
                </div>
                <h3 className="text-base font-bold">
                  {selectedInspectionItem.record.type} · {selectedInspectionItem.permit.id}
                </h3>
              </div>
              <button onClick={() => setChecklistModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCompleteInspection} className="p-6 space-y-6 text-xs">
              {/* Checklist items */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-3">
                  Mandatory Code Verification Items (IBC 2024 / IRC)
                </h4>

                <div className="space-y-2.5">
                  {activeChecklist.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{item.label}</div>
                        <div className="font-mono text-blue-700 text-[10px] mt-0.5">{item.codeRef}</div>
                      </div>

                      {/* Tri-state buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleToggleChecklistStatus(item.id, 'pass')}
                          className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                            item.status === 'pass'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-emerald-50'
                          }`}
                        >
                          Pass
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleChecklistStatus(item.id, 'fail')}
                          className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                            item.status === 'fail'
                              ? 'bg-rose-600 text-white'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-rose-50'
                          }`}
                        >
                          Fail
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleChecklistStatus(item.id, 'na')}
                          className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                            item.status === 'na'
                              ? 'bg-slate-600 text-white'
                              : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          N/A
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Inspector Site Notes */}
              <div>
                <label className="block font-semibold text-slate-900 mb-1">
                  Inspector Site Notes & Code Citations
                </label>
                <textarea
                  rows={3}
                  required
                  value={inspectorNotes}
                  onChange={(e) => setInspectorNotes(e.target.value)}
                  placeholder="Record actual field measurements, nailing spacing verified, or exact corrections required..."
                  className="w-full p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              {/* Final Disposition Result Selection */}
              <div>
                <label className="block font-semibold text-slate-900 mb-2">
                  Official Inspection Disposition
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedResult('passed')}
                    className={`py-3 px-4 rounded-lg border text-center font-bold transition-all ${
                      selectedResult === 'passed'
                        ? 'bg-emerald-600 text-white border-emerald-600 ring-2 ring-emerald-500/30'
                        : 'border-slate-300 text-slate-700 hover:bg-emerald-50'
                    }`}
                  >
                    PASS
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedResult('conditional_pass')}
                    className={`py-3 px-4 rounded-lg border text-center font-bold transition-all ${
                      selectedResult === 'conditional_pass'
                        ? 'bg-amber-600 text-white border-amber-600 ring-2 ring-amber-500/30'
                        : 'border-slate-300 text-slate-700 hover:bg-amber-50'
                    }`}
                  >
                    CONDITIONAL
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedResult('failed')}
                    className={`py-3 px-4 rounded-lg border text-center font-bold transition-all ${
                      selectedResult === 'failed'
                        ? 'bg-rose-600 text-white border-rose-600 ring-2 ring-rose-500/30'
                        : 'border-slate-300 text-slate-700 hover:bg-rose-50'
                    }`}
                  >
                    FAIL (CORRECTION)
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setChecklistModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded shadow-sm"
                >
                  Save & Sign Off Inspection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
