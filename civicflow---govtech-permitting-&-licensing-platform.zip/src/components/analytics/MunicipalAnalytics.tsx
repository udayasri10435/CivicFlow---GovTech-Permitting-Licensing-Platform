import React, { useState } from 'react';
import { PermitApplication } from '../../types/permits';
import { 
  TrendingUp, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  FileSpreadsheet, 
  Download, 
  Building, 
  BarChart3, 
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';

interface MunicipalAnalyticsProps {
  permits: PermitApplication[];
}

export const MunicipalAnalytics: React.FC<MunicipalAnalyticsProps> = ({ permits }) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Compute metrics
  const totalPermits = permits.length;
  const issuedPermits = permits.filter((p) => p.status === 'issued' || p.status === 'inspections_active' || p.status === 'final_approved').length;
  const inReviewPermits = permits.filter((p) => p.status === 'under_review' || p.status === 'corrections_required').length;
  
  // Total fees collected vs pending
  const allFees = permits.flatMap((p) => p.fees);
  const totalCollectedFees = allFees.filter((f) => f.status === 'paid').reduce((a, b) => a + b.amount, 0);
  const totalPendingFees = allFees.filter((f) => f.status === 'unpaid').reduce((a, b) => a + b.amount, 0);
  
  // Total declared construction valuation
  const totalValuation = permits.reduce((acc, p) => acc + p.projectScope.estimatedValuation, 0);

  // Export CSV simulation
  const handleExportCSV = () => {
    const headers = 'Permit Number,Type,Title,Applicant,Address,Valuation,Status,Date Filed\n';
    const rows = permits.map(
      (p) => `"${p.id}","${p.type}","${p.title.replace(/"/g, '""')}","${p.applicant.name}","${p.property.address}","${p.projectScope.estimatedValuation}","${p.status}","${p.submittedDate}"`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `City_of_Oakridge_Permits_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Analytics Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="text-xs text-blue-600 font-semibold uppercase tracking-wider">
            City Governance & Performance Reporting
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Municipal Permitting & Revenue Analytics
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            FY2026 Statutory SLA Compliance, Department Throughput & Master Fee Ledger
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 text-xs font-semibold bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 rounded-lg transition-colors flex items-center gap-2 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>{downloadSuccess ? 'Ledger CSV Downloaded!' : 'Export Public Records (CSV)'}</span>
          </button>
        </div>
      </div>

      {/* High-Level Executive Metric Cards (Compliant with SaaS Single Elevation discipline) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Average Review Turnaround</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">11.4 Days</span>
            <span className="text-emerald-600 text-xs font-medium">↓ 2.6 days vs target</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-mono">
            Oakridge 14-day statutory target
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>YTD Revenue Collected</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">
              ${totalCollectedFees.toLocaleString()}
            </span>
            <span className="text-emerald-600 text-xs font-medium font-mono">100% deposited</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-mono">
            ${totalPendingFees.toLocaleString()} currently in receivables
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Active Capital Valuation</span>
            <Building className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">
              ${(totalValuation / 1000).toFixed(0)}k
            </span>
            <span className="text-purple-600 text-xs font-medium">Under active build</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-mono">
            {permits.length} municipal building permits
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>First-Round Approval Rate</span>
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">78.5%</span>
            <span className="text-slate-500 text-xs font-medium">↑ 4.2% YoY</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-mono">
            Digital plan review standardization
          </div>
        </div>
      </div>

      {/* Department Workload Breakdown & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Workload Table */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Inter-Departmental Queue Load</h2>
              <div className="text-xs text-slate-500">Current active applications per reviewing division</div>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3 text-xs">
            {[
              { name: 'Building Safety Division', active: 4, avgDays: 4.2, status: 'On Target' },
              { name: 'Planning & Zoning', active: 3, avgDays: 5.1, status: 'On Target' },
              { name: 'Fire Protection District', active: 2, avgDays: 3.0, status: 'Ahead of Target' },
              { name: 'Public Works & Utilities', active: 3, avgDays: 4.8, status: 'On Target' },
            ].map((d) => (
              <div key={d.name} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-900">{d.name}</div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Avg turnaround: <strong className="text-slate-700">{d.avgDays} days</strong>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-900 text-sm">{d.active} In Review</div>
                  <div className="text-[10px] text-emerald-700 font-semibold">{d.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Master Fee Schedule Table */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Master Fee Schedule (OMC Title 3)</h2>
              <div className="text-xs text-slate-500">Statutory municipal cost-recovery fee schedule</div>
            </div>
            <FileSpreadsheet className="w-4 h-4 text-slate-400" />
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="py-2 px-3">Fee Classification</th>
                  <th className="py-2 px-3">Municipal Authority</th>
                  <th className="py-2 px-3 text-right">Standard Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                <tr>
                  <td className="py-2 px-3 font-sans">Residential Plan Check</td>
                  <td className="py-2 px-3 text-slate-500 font-sans">OMC § 3.04.010</td>
                  <td className="py-2 px-3 text-right font-bold">$450 + $0.75/sq ft</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans">Commercial Plan Check</td>
                  <td className="py-2 px-3 text-slate-500 font-sans">OMC § 3.04.020</td>
                  <td className="py-2 px-3 text-right font-bold">$850 + $1.15/sq ft</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans">Solar PV & Battery (SolarApp+)</td>
                  <td className="py-2 px-3 text-slate-500 font-sans">Gov Code § 65850.5</td>
                  <td className="py-2 px-3 text-right font-bold">$450 Flat Statutory Cap</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans">Re-Inspection Surcharge</td>
                  <td className="py-2 px-3 text-slate-500 font-sans">OMC § 3.08.040</td>
                  <td className="py-2 px-3 text-right font-bold">$165 per occurrence</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans">Technology Surcharge</td>
                  <td className="py-2 px-3 text-slate-500 font-sans">OMC § 3.12.010</td>
                  <td className="py-2 px-3 text-right font-bold">4.0% of Permit Fees</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
