import React, { useState } from 'react';
import { MUNICIPAL_PARCELS } from '../../data/mockMunicipalData';
import { ParcelInfo, PermitApplication } from '../../types/permits';
import { 
  Map, 
  Layers, 
  Search, 
  MapPin, 
  Building, 
  ShieldAlert, 
  FileText, 
  Info, 
  ExternalLink,
  Plus
} from 'lucide-react';

interface GisParcelExplorerProps {
  permits: PermitApplication[];
  onSelectParcelToApply: (parcel: ParcelInfo) => void;
  onViewPermit: (permitId: string) => void;
}

export const GisParcelExplorer: React.FC<GisParcelExplorerProps> = ({
  permits,
  onSelectParcelToApply,
  onViewPermit,
}) => {
  const [selectedApn, setSelectedApn] = useState<string>(MUNICIPAL_PARCELS[0].apn);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeLayer, setActiveLayer] = useState<'zoning' | 'permits' | 'flood'>('zoning');

  const selectedParcel = MUNICIPAL_PARCELS.find((p) => p.apn === selectedApn) || MUNICIPAL_PARCELS[0];

  const filteredParcels = MUNICIPAL_PARCELS.filter((p) =>
    p.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.apn.includes(searchQuery) ||
    p.owner.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const parcelPermits = permits.filter((p) => p.property.apn === selectedParcel.apn);

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* GIS Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="text-xs text-blue-600 font-semibold uppercase tracking-wider">
            City of Oakridge Geographic Information Systems (GIS)
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Municipal Parcel Registry & Zoning Explorer
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Cadastral parcel boundaries, zoning standards, setbacks, and real-time permit density
          </p>
        </div>

        {/* Layer Controls */}
        <div className="flex items-center gap-2 bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
          <Layers className="w-3.5 h-3.5 text-slate-500 ml-2" />
          <button
            onClick={() => setActiveLayer('zoning')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeLayer === 'zoning' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Zoning Overlay
          </button>
          <button
            onClick={() => setActiveLayer('permits')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeLayer === 'permits' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Active Permits
          </button>
          <button
            onClick={() => setActiveLayer('flood')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeLayer === 'flood' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            FEMA Flood Risk
          </button>
        </div>
      </div>

      {/* Main Layout: Interactive GIS Map Canvas on Top / Parcel Property Card on Bottom */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Map Canvas (7 cols on lg) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
          <div className="bg-slate-900 text-slate-200 px-4 py-2.5 flex items-center justify-between text-xs border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Map className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-semibold">Oakridge Municipal Cadastral Map</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400 font-mono text-[11px]">Coordinate Ref: EPSG:3857</span>
            </div>
            <div className="text-[11px] text-emerald-400 font-mono">Real-time parcel layers</div>
          </div>

          {/* Interactive SVG GIS Map Canvas */}
          <div className="relative bg-[#f8fafc] h-[440px] overflow-hidden select-none border-b border-slate-200 flex items-center justify-center p-4">
            {/* Street Grid Background Vectors */}
            <svg className="w-full h-full" viewBox="0 0 600 400">
              {/* Roads */}
              <rect x="0" y="0" width="600" height="400" fill="#f1f5f9" />
              
              {/* Main Streets */}
              <path d="M 0 180 L 600 180" stroke="#cbd5e1" strokeWidth="26" />
              <path d="M 0 180 L 600 180" stroke="#ffffff" strokeWidth="22" />
              <text x="30" y="184" fill="#94a3b8" fontSize="10" fontFamily="sans-serif" fontWeight="bold">EVERGREEN TERRACE</text>

              <path d="M 280 0 L 280 400" stroke="#cbd5e1" strokeWidth="26" />
              <path d="M 280 0 L 280 400" stroke="#ffffff" strokeWidth="22" />
              <text x="285" y="40" fill="#94a3b8" fontSize="10" fontFamily="sans-serif" fontWeight="bold" transform="rotate(90 285 40)">MAIN STREET (C-2 CORRIDOR)</text>

              <path d="M 0 320 L 600 320" stroke="#cbd5e1" strokeWidth="20" />
              <path d="M 0 320 L 600 320" stroke="#ffffff" strokeWidth="16" />
              <text x="40" y="324" fill="#94a3b8" fontSize="9" fontFamily="sans-serif">INDUSTRIAL PARKWAY</text>

              {/* Parcels Plats */}
              {/* Parcel 1: 042-180-22 (742 Evergreen) */}
              <g
                onClick={() => setSelectedApn('042-180-22')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="40"
                  y="40"
                  width="100"
                  height="120"
                  fill={selectedApn === '042-180-22' ? '#bfdbfe' : activeLayer === 'zoning' ? '#dbeafe' : activeLayer === 'permits' ? '#fef08a' : '#e2e8f0'}
                  stroke={selectedApn === '042-180-22' ? '#2563eb' : '#94a3b8'}
                  strokeWidth={selectedApn === '042-180-22' ? '3' : '1.5'}
                />
                <text x="90" y="90" fill="#1e3a8a" fontSize="10" fontWeight="bold" textAnchor="middle">042-180-22</text>
                <text x="90" y="105" fill="#3b82f6" fontSize="9" textAnchor="middle">R-1 · 742 Evergreen</text>
                {activeLayer === 'permits' && (
                  <circle cx="90" cy="125" r="7" fill="#ef4444" />
                )}
              </g>

              {/* Parcel 2: 042-180-88 (935 Sycamore) */}
              <g
                onClick={() => setSelectedApn('042-180-88')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="150"
                  y="40"
                  width="110"
                  height="120"
                  fill={selectedApn === '042-180-88' ? '#bfdbfe' : activeLayer === 'zoning' ? '#dbeafe' : activeLayer === 'permits' ? '#fef08a' : '#e2e8f0'}
                  stroke={selectedApn === '042-180-88' ? '#2563eb' : '#94a3b8'}
                  strokeWidth={selectedApn === '042-180-88' ? '3' : '1.5'}
                />
                <text x="205" y="90" fill="#1e3a8a" fontSize="10" fontWeight="bold" textAnchor="middle">042-180-88</text>
                <text x="205" y="105" fill="#3b82f6" fontSize="9" textAnchor="middle">R-1 · 935 Sycamore</text>
                {activeLayer === 'permits' && (
                  <circle cx="205" cy="125" r="7" fill="#3b82f6" />
                )}
              </g>

              {/* Parcel 3: 015-092-14 (1204 Main St - Commercial C-2) */}
              <g
                onClick={() => setSelectedApn('015-092-14')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="310"
                  y="40"
                  width="130"
                  height="120"
                  fill={selectedApn === '015-092-14' ? '#fbcfe8' : activeLayer === 'zoning' ? '#fce7f3' : activeLayer === 'permits' ? '#fef08a' : '#e2e8f0'}
                  stroke={selectedApn === '015-092-14' ? '#db2777' : '#94a3b8'}
                  strokeWidth={selectedApn === '015-092-14' ? '3' : '1.5'}
                />
                <text x="375" y="90" fill="#831843" fontSize="10" fontWeight="bold" textAnchor="middle">015-092-14</text>
                <text x="375" y="105" fill="#be185d" fontSize="9" textAnchor="middle">C-2 · 1204 Main St</text>
                {activeLayer === 'permits' && (
                  <circle cx="375" cy="125" r="7" fill="#10b981" />
                )}
              </g>

              {/* Parcel 4: 042-180-45 (816 Foothill - R-3 Multi Family) */}
              <g
                onClick={() => setSelectedApn('042-180-45')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="450"
                  y="40"
                  width="120"
                  height="120"
                  fill={selectedApn === '042-180-45' ? '#fed7aa' : activeLayer === 'zoning' ? '#ffedd5' : activeLayer === 'permits' ? '#fef08a' : '#e2e8f0'}
                  stroke={selectedApn === '042-180-45' ? '#ea580c' : '#94a3b8'}
                  strokeWidth={selectedApn === '042-180-45' ? '3' : '1.5'}
                />
                <text x="510" y="90" fill="#7c2d12" fontSize="10" fontWeight="bold" textAnchor="middle">042-180-45</text>
                <text x="510" y="105" fill="#c2410c" fontSize="9" textAnchor="middle">R-3 · 816 Foothill</text>
              </g>

              {/* Parcel 5: 038-210-09 (450 Industrial Pkwy - M-1 Light Industrial & Flood Zone) */}
              <g
                onClick={() => setSelectedApn('038-210-09')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="40"
                  y="210"
                  width="220"
                  height="90"
                  fill={selectedApn === '038-210-09' ? '#e9d5ff' : activeLayer === 'flood' ? '#bfdbfe' : activeLayer === 'zoning' ? '#f3e8ff' : '#e2e8f0'}
                  stroke={selectedApn === '038-210-09' ? '#7e22ce' : '#94a3b8'}
                  strokeWidth={selectedApn === '038-210-09' ? '3' : '1.5'}
                />
                <text x="150" y="245" fill="#581c87" fontSize="11" fontWeight="bold" textAnchor="middle">038-210-09</text>
                <text x="150" y="260" fill="#7e22ce" fontSize="9" textAnchor="middle">M-1 Industrial · 450 Industrial Pkwy</text>
                {activeLayer === 'flood' && (
                  <text x="150" y="280" fill="#1e40af" fontSize="9" fontWeight="bold" textAnchor="middle">⚠ FEMA 100-YR FLOOD ZONE AE</text>
                )}
              </g>

              {/* Parcel 6: 042-180-91 (1020 Cedar Valley) */}
              <g
                onClick={() => setSelectedApn('042-180-91')}
                className="cursor-pointer transition-opacity hover:opacity-85"
              >
                <rect
                  x="310"
                  y="210"
                  width="260"
                  height="90"
                  fill={selectedApn === '042-180-91' ? '#bfdbfe' : activeLayer === 'zoning' ? '#dbeafe' : '#e2e8f0'}
                  stroke={selectedApn === '042-180-91' ? '#2563eb' : '#94a3b8'}
                  strokeWidth={selectedApn === '042-180-91' ? '3' : '1.5'}
                />
                <text x="440" y="245" fill="#1e3a8a" fontSize="11" fontWeight="bold" textAnchor="middle">042-180-91</text>
                <text x="440" y="260" fill="#3b82f6" fontSize="9" textAnchor="middle">R-1 · 1020 Cedar Valley Way</text>
              </g>
            </svg>
          </div>

          {/* Map Legend */}
          <div className="p-3 bg-slate-50 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-600 font-mono">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded bg-blue-100 border border-blue-400" />
                <span className="font-sans text-[11px]">R-1 Single Family</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded bg-orange-100 border border-orange-400" />
                <span className="font-sans text-[11px]">R-3 Multi Family</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded bg-pink-100 border border-pink-400" />
                <span className="font-sans text-[11px]">C-2 Commercial</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded bg-purple-100 border border-purple-400" />
                <span className="font-sans text-[11px]">M-1 Light Industrial</span>
              </span>
            </div>
            <div className="text-slate-400 font-sans text-[11px]">
              Click any parcel polygon to view zoning specifications
            </div>
          </div>
        </div>

        {/* Parcel Details Card (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-5">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-mono text-slate-400 uppercase">Selected Tax Parcel</span>
                <h2 className="text-base font-bold text-slate-900 font-mono mt-0.5">
                  APN {selectedParcel.apn}
                </h2>
                <div className="text-xs text-slate-600 mt-1">{selectedParcel.address}</div>
              </div>

              <button
                onClick={() => onSelectParcelToApply(selectedParcel)}
                className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors flex items-center gap-1 shadow-sm shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Apply on Parcel</span>
              </button>
            </div>

            {/* Zoning specifications table */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 font-mono">
                <span className="text-slate-500 block text-[10px] font-sans">Zoning District</span>
                <strong className="text-slate-900 text-sm">{selectedParcel.zoning}</strong>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">{selectedParcel.zoningDescription}</div>
              </div>

              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 font-mono">
                <span className="text-slate-500 block text-[10px] font-sans">Lot Area</span>
                <strong className="text-slate-900 text-sm">{selectedParcel.lotSizeSqFt.toLocaleString()} sq ft</strong>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">{(selectedParcel.lotSizeSqFt / 43560).toFixed(2)} Acres</div>
              </div>

              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 font-mono">
                <span className="text-slate-500 block text-[10px] font-sans">Max Building Height</span>
                <strong className="text-slate-900 text-sm">{selectedParcel.maxHeightFt} Feet</strong>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">OMC § 17.12 Standard</div>
              </div>

              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 font-mono">
                <span className="text-slate-500 block text-[10px] font-sans">FEMA Flood Risk</span>
                <strong className={`text-sm ${selectedParcel.floodZone.includes('AE') ? 'text-amber-700' : 'text-slate-900'}`}>
                  {selectedParcel.floodZone}
                </strong>
                <div className="text-[10px] text-slate-500 font-sans mt-0.5">Firm Panel #06097C</div>
              </div>
            </div>

            {/* Required Setbacks */}
            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-xs">
              <div className="font-semibold text-slate-800 mb-1">Municipal Setback Requirements</div>
              <div className="grid grid-cols-3 gap-2 text-center font-mono text-[11px]">
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[9px] font-sans">Front</span>
                  <strong className="text-slate-900">{selectedParcel.setbacks.front} ft</strong>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[9px] font-sans">Side</span>
                  <strong className="text-slate-900">{selectedParcel.setbacks.side} ft</strong>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[9px] font-sans">Rear</span>
                  <strong className="text-slate-900">{selectedParcel.setbacks.rear} ft</strong>
                </div>
              </div>
            </div>

            {/* Active & Past Permits on this Tax Parcel */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Permits Associated With APN ({parcelPermits.length})
                </h3>
              </div>

              <div className="space-y-2">
                {parcelPermits.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => onViewPermit(p.id)}
                    className="p-3 rounded-lg border border-slate-200 hover:border-blue-400 cursor-pointer transition-colors bg-white text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-mono font-bold text-slate-900">{p.id}</div>
                      <div className="font-medium text-slate-700 line-clamp-1">{p.title}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">Filed {p.submittedDate}</div>
                    </div>
                    <span className="text-[10px] font-bold uppercase text-blue-700 font-mono">
                      {p.status.replace('_', ' ')}
                    </span>
                  </div>
                ))}

                {parcelPermits.length === 0 && (
                  <div className="p-4 bg-slate-50 rounded border border-slate-200 text-center text-xs text-slate-500">
                    No active permits on record for this parcel.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
