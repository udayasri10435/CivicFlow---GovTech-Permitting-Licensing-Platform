import React from 'react';
import { PermitApplication } from '../../types/permits';
import { Printer, Shield, CheckCircle2, QrCode, X, Calendar, MapPin, Building2, User } from 'lucide-react';

interface OfficialPermitCertificateProps {
  permit: PermitApplication;
  onClose: () => void;
}

export const OfficialPermitCertificate: React.FC<OfficialPermitCertificateProps> = ({
  permit,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const isIssued = permit.status === 'issued' || permit.status === 'inspections_active' || permit.status === 'final_approved';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white text-slate-900 w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden my-8 border border-slate-200">
        {/* Certificate Header Action Bar */}
        <div className="bg-slate-900 text-white px-6 py-3 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Shield className="w-4 h-4 text-amber-400" />
            <span>Official Municipal Document · City of Oakridge</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-500 rounded text-white flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Permit / Job Card</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Certificate Document */}
        <div className="p-8 sm:p-12 print:p-0">
          {/* Certificate Border */}
          <div className="border-4 border-double border-slate-800 p-6 sm:p-8 relative">
            {/* Corner Decorative Ornaments */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-slate-700" />
            <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-slate-700" />
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-slate-700" />
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-slate-700" />

            {/* Header Lockup */}
            <div className="text-center pb-6 border-b-2 border-slate-800">
              <div className="flex justify-center mb-2">
                <div className="w-16 h-16 rounded-full bg-slate-900 text-amber-400 flex flex-col items-center justify-center border-2 border-amber-400/60 font-serif font-black">
                  <span className="text-[10px] tracking-widest text-slate-300">EST.</span>
                  <span className="text-xs">1889</span>
                  <span className="text-[8px] uppercase tracking-tighter text-amber-300">Oakridge</span>
                </div>
              </div>
              <h1 className="text-2xl font-black tracking-wider text-slate-900 uppercase font-serif">
                City of Oakridge
              </h1>
              <div className="text-xs font-semibold tracking-widest text-slate-600 uppercase mt-0.5">
                Department of Community Development & Building Safety
              </div>
              <div className="mt-3 inline-block px-4 py-1 bg-slate-100 border border-slate-400 text-sm font-bold uppercase tracking-widest text-slate-900">
                Official Building & Construction Permit
              </div>
            </div>

            {/* Key Permit Identifier Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-slate-300 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Permit Number</span>
                <span className="font-bold text-sm text-slate-900">{permit.id}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Date Issued</span>
                <span className="font-bold text-sm text-slate-900">{permit.issuedDate || '2026-09-28'}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Expiration Date</span>
                <span className="font-bold text-sm text-slate-900">{permit.expirationDate || '2027-03-28'}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Status</span>
                <span className="font-bold text-sm text-emerald-700 uppercase">
                  {permit.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Property & Applicant Specification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 py-5 border-b border-slate-300 text-xs">
              <div>
                <h3 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-600" />
                  <span>Job Site Location</span>
                </h3>
                <div className="space-y-1 text-slate-700">
                  <p className="font-semibold text-slate-900 text-sm">{permit.property.address}</p>
                  <p>
                    <span className="text-slate-500">APN:</span> <span className="font-mono">{permit.property.apn}</span>
                    <span className="mx-2 text-slate-400">·</span>
                    <span className="text-slate-500">Zoning:</span> <span className="font-semibold">{permit.property.zoning}</span>
                  </p>
                  <p>
                    <span className="text-slate-500">Lot Area:</span>{' '}
                    <span className="font-mono">{permit.property.lotSizeSqFt.toLocaleString()} sq ft</span>
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-600" />
                  <span>Permittee / Licensed Contractor</span>
                </h3>
                <div className="space-y-1 text-slate-700">
                  <p className="font-semibold text-slate-900 text-sm">
                    {permit.applicant.company || permit.applicant.name}
                  </p>
                  <p>
                    <span className="text-slate-500">State License #:</span>{' '}
                    <span className="font-mono font-medium">{permit.applicant.licenseNumber || 'Owner-Builder Declaration on File'}</span>
                  </p>
                  <p>
                    <span className="text-slate-500">Authorized Contact:</span>{' '}
                    <span>{permit.applicant.name} ({permit.applicant.phone})</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Scope of Authorized Work */}
            <div className="py-4 border-b border-slate-300 text-xs">
              <h3 className="font-bold text-slate-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-slate-600" />
                <span>Scope of Authorized Work</span>
              </h3>
              <p className="text-slate-800 leading-relaxed font-serif text-[13px] bg-slate-50 p-2.5 rounded border border-slate-200">
                {permit.projectScope.description}
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 text-[11px] text-slate-600 font-mono">
                <div>Occupancy: <strong className="text-slate-800">{permit.projectScope.occupancyGroup}</strong></div>
                <div>Const. Type: <strong className="text-slate-800">{permit.projectScope.constructionType}</strong></div>
                <div>Area: <strong className="text-slate-800">{permit.projectScope.squareFootage} sq ft</strong></div>
                <div>Declared Valuation: <strong className="text-slate-800">${permit.projectScope.estimatedValuation.toLocaleString()}</strong></div>
              </div>
            </div>

            {/* Conditions of Approval */}
            <div className="py-4 border-b border-slate-300 text-xs">
              <h3 className="font-bold text-slate-800 uppercase tracking-wider mb-2">
                Mandatory Conditions of Approval & Municipal Notices
              </h3>
              <ul className="list-disc pl-5 space-y-1 text-slate-700 text-[11px]">
                <li>This permit becomes null and void if work is not commenced within 180 days of issuance.</li>
                <li>The approved stamped plan set and inspection job card must be posted in a visible, weather-protected location on site.</li>
                <li>No work shall be concealed or covered until inspected and signed off by the City Building Inspector.</li>
                {permit.conditionsOfApproval?.map((c, i) => (
                  <li key={i} className="font-medium text-slate-900">{c}</li>
                ))}
              </ul>
            </div>

            {/* Mandatory Inspection Sign-Off Job Card */}
            <div className="py-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-900 uppercase tracking-wider text-xs">
                  Field Inspection Record & Sign-Off Schedule
                </h3>
                <span className="text-[10px] text-slate-500 font-mono">Official Inspector Stamp Required for Each Phase</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border border-slate-300">
                  <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-300">
                    <tr>
                      <th className="py-1.5 px-3">Inspection Stage</th>
                      <th className="py-1.5 px-3">Inspector Signature / Badge #</th>
                      <th className="py-1.5 px-3">Date Completed</th>
                      <th className="py-1.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                    {[
                      { stage: '1. Foundation / Footing Trench', samplePassed: true, date: '2026-08-05', inspector: 'B. Martinez #412' },
                      { stage: '2. Under-Slab Plumbing & Conduit', samplePassed: true, date: '2026-08-12', inspector: 'B. Martinez #412' },
                      { stage: '3. Rough Framing & Structural', samplePassed: permit.inspections.some((i) => i.status === 'passed' && i.type.includes('Framing')), date: 'Pending', inspector: '—' },
                      { stage: '4. Rough Electrical, Plumbing & HVAC', samplePassed: false, date: 'Pending', inspector: '—' },
                      { stage: '5. Insulation & Energy Verification', samplePassed: false, date: 'Pending', inspector: '—' },
                      { stage: '6. Drywall / Lath Fastener Pattern', samplePassed: false, date: 'Pending', inspector: '—' },
                      { stage: '7. Final Building & Certificate of Occupancy', samplePassed: permit.status === 'final_approved', date: permit.status === 'final_approved' ? '2026-06-02' : 'Pending', inspector: permit.status === 'final_approved' ? 'B. Martinez #412' : '—' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-sans font-medium text-slate-900">{row.stage}</td>
                        <td className="py-2 px-3 text-slate-700">{row.samplePassed ? row.inspector : '_______________'}</td>
                        <td className="py-2 px-3 text-slate-700">{row.samplePassed ? row.date : '__/__/____'}</td>
                        <td className="py-2 px-3">
                          {row.samplePassed ? (
                            <span className="text-emerald-700 font-bold">APPROVED</span>
                          ) : (
                            <span className="text-slate-400">PENDING CALL</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bottom Verification & Signatures */}
            <div className="pt-6 border-t-2 border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 border-2 border-slate-800 p-1 flex items-center justify-center bg-slate-50">
                  <QrCode className="w-12 h-12 text-slate-800" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">VERIFY VIA CIVICFLOW PUBLIC LEDGER</div>
                  <div className="text-[10px] text-slate-500 font-mono">hash: 991c353e-d60d-4187-a8ab-cf938719bdf0</div>
                  <div className="text-[10px] text-slate-600 mt-0.5">Scan on job site to view real-time inspection records</div>
                </div>
              </div>

              <div className="text-right">
                <div className="font-serif italic text-lg text-slate-900">David K. Miller, CBO</div>
                <div className="w-48 border-b border-slate-700 my-1 ml-auto" />
                <div className="text-[10px] uppercase font-semibold text-slate-600 tracking-wider">
                  Chief Building Official · City of Oakridge
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
