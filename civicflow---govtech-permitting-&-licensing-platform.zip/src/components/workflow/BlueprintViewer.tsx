import React, { useState } from 'react';
import { BlueprintMarkup, DepartmentType } from '../../types/permits';
import { MUNICIPAL_CODE_LIBRARY } from '../../data/mockMunicipalData';
import { Layers, ZoomIn, ZoomOut, RotateCcw, AlertTriangle, CheckCircle, Plus, Stamp, X } from 'lucide-react';

interface BlueprintViewerProps {
  markups: BlueprintMarkup[];
  onAddMarkup: (markup: Omit<BlueprintMarkup, 'id' | 'timestamp'>) => void;
  onResolveMarkup: (id: string) => void;
  onApplyStamp?: (stampType: string) => void;
  readOnly?: boolean;
}

export const BlueprintViewer: React.FC<BlueprintViewerProps> = ({
  markups,
  onAddMarkup,
  onResolveMarkup,
  onApplyStamp,
  readOnly = false,
}) => {
  const [activeSheet, setActiveSheet] = useState<'A-1' | 'A-2' | 'P-1'>('A-2');
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [activeMarkupModal, setActiveMarkupModal] = useState<{ xPercent: number; yPercent: number } | null>(null);
  const [newComment, setNewComment] = useState('');
  const [selectedCode, setSelectedCode] = useState(MUNICIPAL_CODE_LIBRARY[0].code);
  const [selectedDept, setSelectedDept] = useState<DepartmentType>('building');
  const [selectedMarkupDetail, setSelectedMarkupDetail] = useState<BlueprintMarkup | null>(null);
  const [stampsApplied, setStampsApplied] = useState<string[]>([]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (readOnly) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setActiveMarkupModal({ xPercent: Math.round(x), yPercent: Math.round(y) });
  };

  const handleSaveMarkup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMarkupModal || !newComment.trim()) return;

    onAddMarkup({
      sheet: activeSheet === 'A-1' ? 'Sheet A-1 (Floor Plan)' : activeSheet === 'A-2' ? 'Sheet A-2 (Roof & Elevations)' : 'Sheet P-1 (Plumbing Schedule)',
      xPercent: activeMarkupModal.xPercent,
      yPercent: activeMarkupModal.yPercent,
      author: 'David K. Miller, CBO (Building Safety)',
      department: selectedDept,
      comment: newComment.trim(),
      status: 'open',
      codeCitation: selectedCode,
    });

    setNewComment('');
    setActiveMarkupModal(null);
  };

  const handleAddStamp = (stampName: string) => {
    if (!stampsApplied.includes(stampName)) {
      setStampsApplied([...stampsApplied, stampName]);
      if (onApplyStamp) onApplyStamp(stampName);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden text-slate-100 flex flex-col">
      {/* Top Toolbar */}
      <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-slate-200">Digital Plan Room Viewer</span>
          <span className="text-slate-600">·</span>
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800">
            <button
              onClick={() => setActiveSheet('A-1')}
              className={`px-2.5 py-1 rounded transition-colors ${
                activeSheet === 'A-1' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
            >
              A-1 Floor Plan
            </button>
            <button
              onClick={() => setActiveSheet('A-2')}
              className={`px-2.5 py-1 rounded transition-colors ${
                activeSheet === 'A-2' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
            >
              A-2 Elevations & Roof
            </button>
            <button
              onClick={() => setActiveSheet('P-1')}
              className={`px-2.5 py-1 rounded transition-colors ${
                activeSheet === 'P-1' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
              }`}
            >
              P-1 Plumbing DWV
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {!readOnly && (
            <div className="flex items-center gap-1 mr-2">
              <button
                onClick={() => handleAddStamp('CITY OF OAKRIDGE - APPROVED AS NOTED')}
                className="px-2.5 py-1 text-[11px] font-medium bg-emerald-950 text-emerald-300 border border-emerald-800 rounded hover:bg-emerald-900 transition-colors flex items-center gap-1"
                title="Apply municipal plan check approval stamp"
              >
                <Stamp className="w-3 h-3" />
                <span>Stamp: Approved as Noted</span>
              </button>
            </div>
          )}

          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5">
            <button
              onClick={() => setZoomLevel(Math.max(75, zoomLevel - 15))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 font-mono text-[11px] text-slate-300">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel(Math.min(150, zoomLevel + 15))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(100)}
              className="p-1 text-slate-400 hover:text-white border-l border-slate-800 ml-1 transition-colors"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Blueprint Drawing Surface */}
      <div className="relative bg-[#0d1b2a] min-h-[460px] overflow-auto flex items-center justify-center p-6 select-none">
        <div
          onClick={handleCanvasClick}
          style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'center center' }}
          className={`relative w-[760px] h-[460px] bg-[#091522] border-2 border-blue-900/60 shadow-2xl transition-transform ${
            !readOnly ? 'cursor-crosshair' : 'cursor-default'
          }`}
        >
          {/* Blueprint Grid Lines */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'linear-gradient(to right, #38bdf8 1px, transparent 1px), linear-gradient(to bottom, #38bdf8 1px, transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />

          {/* Architectural Drawing Vectors depending on Sheet */}
          {activeSheet === 'A-2' && (
            <svg className="w-full h-full text-sky-300/80 pointer-events-none" viewBox="0 0 760 460">
              {/* Title Block Border */}
              <rect x="20" y="20" width="720" height="420" fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeOpacity="0.4" />
              {/* Title Block Box in Corner */}
              <rect x="520" y="370" width="220" height="70" fill="#0b1b2d" stroke="#38bdf8" strokeWidth="1" strokeOpacity="0.6" />
              <text x="530" y="390" fill="#93c5fd" fontSize="10" fontFamily="sans-serif" fontWeight="bold">CITY OF OAKRIDGE PLAN REVIEW</text>
              <text x="530" y="405" fill="#e0f2fe" fontSize="12" fontFamily="sans-serif" fontWeight="bold">SHEET A-2: ROOF & ELEVATIONS</text>
              <text x="530" y="420" fill="#94a3b8" fontSize="9" fontFamily="monospace">SCALE: 1/4" = 1\'-0" · APN 042-180-22</text>
              <text x="530" y="432" fill="#38bdf8" fontSize="9" fontFamily="sans-serif">HIGHLAND MODERN BUILDERS LLC</text>

              {/* House Roof & Elevation Profiles */}
              <g stroke="#7dd3fc" strokeWidth="1.8" fill="none">
                {/* Main Ground Line */}
                <line x1="60" y1="360" x2="680" y2="360" stroke="#38bdf8" strokeWidth="2.5" />
                {/* Elevation structure */}
                <rect x="140" y="180" width="460" height="180" stroke="#bae6fd" strokeWidth="2" fill="#0e2338" fillOpacity="0.6" />
                {/* Roof Ridge & Gable */}
                <polyline points="120,180 370,80 620,180" stroke="#38bdf8" strokeWidth="2.5" />
                <polyline points="140,180 370,88 600,180" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4" />

                {/* Overhang Callout Area (Where Building Division had comment) */}
                <rect x="590" y="170" width="50" height="40" fill="#f43f5e" fillOpacity="0.15" stroke="#f43f5e" strokeWidth="1" strokeDasharray="3 3" />
                <text x="600" y="165" fill="#f87171" fontSize="9" fontWeight="bold">REAR YARD OVERHANG</text>

                {/* Fenestrations: Windows & Patio Door */}
                <rect x="180" y="220" width="80" height="90" stroke="#7dd3fc" strokeWidth="1.5" />
                <line x1="220" y1="220" x2="220" y2="310" stroke="#7dd3fc" strokeWidth="1" />
                <rect x="320" y="210" width="100" height="150" stroke="#7dd3fc" strokeWidth="1.5" />
                <line x1="370" y1="210" x2="370" y2="360" stroke="#7dd3fc" strokeWidth="1" />
                <rect x="470" y="230" width="90" height="70" stroke="#7dd3fc" strokeWidth="1.5" />

                {/* Dimension strings */}
                <line x1="140" y1="380" x2="600" y2="380" stroke="#93c5fd" strokeWidth="1" markerEnd="url(#arrow)" />
                <line x1="140" y1="375" x2="140" y2="385" stroke="#93c5fd" strokeWidth="1" />
                <line x1="600" y1="375" x2="600" y2="385" stroke="#93c5fd" strokeWidth="1" />
                <text x="350" y="395" fill="#93c5fd" fontSize="10" fontFamily="monospace" textAnchor="middle">42'-0" TOTAL WIDTH</text>

                {/* Height dimension */}
                <line x1="100" y1="80" x2="100" y2="360" stroke="#93c5fd" strokeWidth="1" />
                <text x="85" y="220" fill="#93c5fd" fontSize="10" fontFamily="monospace" transform="rotate(-90 85 220)" textAnchor="middle">14'-8" MAX RIDGE</text>
              </g>
            </svg>
          )}

          {activeSheet === 'A-1' && (
            <svg className="w-full h-full text-sky-300/80 pointer-events-none" viewBox="0 0 760 460">
              <rect x="20" y="20" width="720" height="420" fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeOpacity="0.4" />
              <rect x="520" y="370" width="220" height="70" fill="#0b1b2d" stroke="#38bdf8" strokeWidth="1" />
              <text x="530" y="390" fill="#93c5fd" fontSize="10" fontFamily="sans-serif" fontWeight="bold">CITY OF OAKRIDGE PLAN REVIEW</text>
              <text x="530" y="405" fill="#e0f2fe" fontSize="12" fontFamily="sans-serif" fontWeight="bold">SHEET A-1: 750 SQ FT FLOOR PLAN</text>
              <text x="530" y="420" fill="#94a3b8" fontSize="9" fontFamily="monospace">SCALE: 1/4" = 1\'-0"</text>

              {/* Exterior Walls */}
              <rect x="100" y="70" width="460" height="280" fill="#0b1e33" stroke="#38bdf8" strokeWidth="3" />
              {/* Interior Partitions */}
              <line x1="280" y1="70" x2="280" y2="350" stroke="#7dd3fc" strokeWidth="2" />
              <line x1="280" y1="210" x2="560" y2="210" stroke="#7dd3fc" strokeWidth="2" />
              <line x1="420" y1="70" x2="420" y2="210" stroke="#7dd3fc" strokeWidth="2" />

              {/* Room Labels */}
              <text x="180" y="200" fill="#bae6fd" fontSize="13" fontWeight="bold" textAnchor="middle">LIVING / DINING</text>
              <text x="180" y="220" fill="#7dd3fc" fontSize="10" fontFamily="monospace" textAnchor="middle">280 SQ FT</text>

              <text x="350" y="140" fill="#bae6fd" fontSize="12" fontWeight="bold" textAnchor="middle">BEDROOM 1</text>
              <text x="350" y="155" fill="#7dd3fc" fontSize="9" fontFamily="monospace" textAnchor="middle">135 SQ FT</text>

              <text x="490" y="140" fill="#bae6fd" fontSize="12" fontWeight="bold" textAnchor="middle">BEDROOM 2</text>
              <text x="490" y="155" fill="#7dd3fc" fontSize="9" fontFamily="monospace" textAnchor="middle">125 SQ FT</text>

              <text x="420" y="280" fill="#bae6fd" fontSize="12" fontWeight="bold" textAnchor="middle">BATHROOM & HVAC</text>
              <text x="420" y="295" fill="#7dd3fc" fontSize="9" fontFamily="monospace" textAnchor="middle">FULL ADA BATH</text>
            </svg>
          )}

          {activeSheet === 'P-1' && (
            <svg className="w-full h-full text-sky-300/80 pointer-events-none" viewBox="0 0 760 460">
              <rect x="20" y="20" width="720" height="420" fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeOpacity="0.4" />
              <rect x="520" y="370" width="220" height="70" fill="#0b1b2d" stroke="#38bdf8" strokeWidth="1" />
              <text x="530" y="390" fill="#93c5fd" fontSize="10" fontFamily="sans-serif" fontWeight="bold">CITY OF OAKRIDGE PLAN REVIEW</text>
              <text x="530" y="405" fill="#e0f2fe" fontSize="12" fontFamily="sans-serif" fontWeight="bold">SHEET P-1: PLUMBING ISOMETRIC</text>
              <text x="530" y="420" fill="#94a3b8" fontSize="9" fontFamily="monospace">CPC 2024 COMPLIANT</text>

              {/* Water & Drain Lines */}
              <path d="M 120 320 L 300 320 L 450 320 L 520 220" fill="none" stroke="#38bdf8" strokeWidth="3" />
              <path d="M 300 320 L 300 180 L 300 70" fill="none" stroke="#a78bfa" strokeWidth="2" strokeDasharray="5 3" />
              <circle cx="120" cy="320" r="6" fill="#38bdf8" />
              <text x="120" y="340" fill="#bae6fd" fontSize="9" fontFamily="monospace">4" BUILDING SEWER TO LATERAL</text>
              <circle cx="300" cy="320" r="6" fill="#f59e0b" />
              <text x="270" y="340" fill="#fcd34d" fontSize="9" fontFamily="monospace">CLEANOUT REQUIRED</text>
            </svg>
          )}

          {/* Applied Municipal Approval Stamps */}
          {stampsApplied.map((stamp, idx) => (
            <div
              key={idx}
              className="absolute top-10 left-10 border-2 border-emerald-500 text-emerald-400 bg-emerald-950/80 px-4 py-2 rounded uppercase tracking-wider font-mono text-xs font-black shadow-lg transform -rotate-6 pointer-events-none select-none"
            >
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>{stamp}</span>
              </div>
              <div className="text-[10px] text-emerald-300 font-normal">
                OFFICIAL RECORD · {new Date().toLocaleDateString()}
              </div>
            </div>
          ))}

          {/* Render Redline Markup Pins */}
          {markups.map((m) => (
            <div
              key={m.id}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedMarkupDetail(m);
              }}
              style={{ left: `${m.xPercent}%`, top: `${m.yPercent}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20 group`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow-lg transition-transform group-hover:scale-125 ${
                  m.status === 'open'
                    ? 'bg-rose-600 text-white animate-pulse ring-4 ring-rose-500/40'
                    : 'bg-emerald-600 text-white'
                }`}
              >
                !
              </div>

              {/* Pin Hover Preview */}
              <div className="hidden group-hover:block absolute bottom-8 left-1/2 -translate-x-1/2 w-64 bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded shadow-xl text-left pointer-events-none z-30">
                <div className="text-[10px] uppercase font-semibold text-rose-400 tracking-wider">
                  {m.department} Review · {m.codeCitation || 'Code Note'}
                </div>
                <div className="text-xs font-medium text-slate-200 mt-1 line-clamp-2">{m.comment}</div>
                <div className="text-[10px] text-slate-400 mt-1.5">{m.author}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Blueprint Helper Bar */}
      <div className="bg-slate-950 px-4 py-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <div>
          {!readOnly ? (
            <span>Click anywhere on the plan sheet to drop an official code revision pin.</span>
          ) : (
            <span>Plan Review Viewport. Select pins to inspect municipal notes.</span>
          )}
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
            <span>Open Revisions: {markups.filter((m) => m.status === 'open').length}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span>Resolved: {markups.filter((m) => m.status === 'resolved').length}</span>
          </span>
        </div>
      </div>

      {/* New Markup Modal */}
      {activeMarkupModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-lg w-full p-5 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <h3 className="text-sm font-semibold">Add Municipal Plan Review Correction</h3>
              </div>
              <button
                onClick={() => setActiveMarkupModal(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveMarkup} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Reviewing Department</label>
                  <select
                    value={selectedDept}
                    onChange={(e) => setSelectedDept(e.target.value as DepartmentType)}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  >
                    <option value="building">Building Safety</option>
                    <option value="zoning">Planning & Zoning</option>
                    <option value="fire">Fire Protection District</option>
                    <option value="public_works">Public Works / Engineering</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Standard Code Citation</label>
                  <select
                    value={selectedCode}
                    onChange={(e) => {
                      setSelectedCode(e.target.value);
                      const std = MUNICIPAL_CODE_LIBRARY.find((c) => c.code === e.target.value);
                      if (std && !newComment) setNewComment(std.standardCondition);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  >
                    {MUNICIPAL_CODE_LIBRARY.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} - {c.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Specific Plan Revision Instruction (Sent to Applicant)
                </label>
                <textarea
                  rows={3}
                  required
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Detail exact dimension, firewall rating, or specification required to satisfy municipal code..."
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2.5 text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveMarkupModal(null)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded transition-colors"
                >
                  Post Correction Pin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Selected Markup Details Modal */}
      {selectedMarkupDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-md w-full p-5 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    selectedMarkupDetail.status === 'open' ? 'bg-rose-500' : 'bg-emerald-500'
                  }`}
                />
                <h3 className="text-sm font-semibold">Plan Revision Note</h3>
              </div>
              <button
                onClick={() => setSelectedMarkupDetail(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span>{selectedMarkupDetail.sheet}</span>
                <span className="font-mono">{selectedMarkupDetail.timestamp}</span>
              </div>
              <div className="p-3 bg-slate-800 rounded border border-slate-700 text-slate-200">
                <div className="font-semibold text-rose-400 text-xs mb-1">
                  {selectedMarkupDetail.codeCitation || 'Code Requirement'}
                </div>
                {selectedMarkupDetail.comment}
              </div>
              <div className="text-slate-400">
                Assigned by: <span className="text-slate-200 font-medium">{selectedMarkupDetail.author}</span>
              </div>
            </div>

            <div className="mt-6 flex justify-between items-center pt-3 border-t border-slate-800">
              <span className="text-xs text-slate-400">
                Status: <strong className="capitalize text-slate-200">{selectedMarkupDetail.status}</strong>
              </span>
              <div className="flex gap-2">
                {selectedMarkupDetail.status === 'open' && (
                  <button
                    onClick={() => {
                      onResolveMarkup(selectedMarkupDetail.id);
                      setSelectedMarkupDetail(null);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded transition-colors"
                  >
                    Mark as Resolved
                  </button>
                )}
                <button
                  onClick={() => setSelectedMarkupDetail(null)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
