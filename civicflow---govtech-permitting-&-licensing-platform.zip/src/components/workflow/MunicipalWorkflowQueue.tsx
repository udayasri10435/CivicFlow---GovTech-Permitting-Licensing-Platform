import React, { useState } from 'react';
import { 
  PermitApplication, 
  DepartmentType, 
  DepartmentReview, 
  BlueprintMarkup, 
  UserRole 
} from '../../types/permits';
import { BlueprintViewer } from './BlueprintViewer';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Search, 
  FileText, 
  Layers, 
  DollarSign, 
  Send, 
  UserCheck, 
  ChevronRight, 
  ShieldCheck, 
  X,
  FileCheck,
  Plus
} from 'lucide-react';

interface MunicipalWorkflowQueueProps {
  permits: PermitApplication[];
  activeRole: UserRole;
  onUpdatePermit: (updatedPermit: PermitApplication) => void;
  onViewCertificate: (permit: PermitApplication) => void;
  selectedPermitId?: string | null;
  onSelectPermitId?: (id: string | null) => void;
}

export const MunicipalWorkflowQueue: React.FC<MunicipalWorkflowQueueProps> = ({
  permits,
  activeRole,
  onUpdatePermit,
  onViewCertificate,
  selectedPermitId,
  onSelectPermitId,
}) => {
  const [activeDeptFilter, setActiveDeptFilter] = useState<'all' | DepartmentType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [internalSelectedId, setInternalSelectedId] = useState<string | null>(selectedPermitId || permits[0]?.id || null);

  const activeId = selectedPermitId !== undefined ? selectedPermitId : internalSelectedId;
  const setActiveId = (id: string | null) => {
    if (onSelectPermitId) onSelectPermitId(id);
    setInternalSelectedId(id);
  };

  const selectedPermit = permits.find((p) => p.id === activeId) || permits[0];

  // Correction notice draft state
  const [isDraftingNotice, setIsDraftingNotice] = useState(false);
  const [correctionNote, setCorrectionNote] = useState('');

  // Department review actions
  const handleDepartmentStatusChange = (
    dept: DepartmentType,
    newStatus: 'approved' | 'revisions_requested' | 'in_review',
    commentText?: string
  ) => {
    if (!selectedPermit) return;

    const updatedReviews = selectedPermit.departmentReviews.map((r) => {
      if (r.department === dept) {
        return {
          ...r,
          status: newStatus,
          completedDate: newStatus === 'approved' ? new Date().toISOString().split('T')[0] : r.completedDate,
          comments: commentText || r.comments,
        };
      }
      return r;
    });

    // Check if all are approved
    const allApproved = updatedReviews.every((r) => r.status === 'approved');
    const hasRevisions = updatedReviews.some((r) => r.status === 'revisions_requested');

    let updatedPermitStatus = selectedPermit.status;
    if (hasRevisions) {
      updatedPermitStatus = 'corrections_required';
    } else if (allApproved) {
      updatedPermitStatus = 'ready_for_payment';
    } else {
      updatedPermitStatus = 'under_review';
    }

    const updatedPermit: PermitApplication = {
      ...selectedPermit,
      status: updatedPermitStatus,
      departmentReviews: updatedReviews,
      timeline: [
        ...selectedPermit.timeline,
        {
          id: `tl-${Date.now()}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          author: `Department Examiner (${dept.toUpperCase()})`,
          action: `Review Status: ${newStatus.replace('_', ' ').toUpperCase()}`,
          details: commentText || `Updated department review state to ${newStatus}`,
        },
      ],
    };

    onUpdatePermit(updatedPermit);
  };

  // Add blueprint markup
  const handleAddMarkup = (newMarkup: Omit<BlueprintMarkup, 'id' | 'timestamp'>) => {
    if (!selectedPermit) return;

    const markupObj: BlueprintMarkup = {
      ...newMarkup,
      id: `mk-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    const updatedPermit: PermitApplication = {
      ...selectedPermit,
      markups: [...selectedPermit.markups, markupObj],
      status: 'corrections_required',
      timeline: [
        ...selectedPermit.timeline,
        {
          id: `tl-mk-${Date.now()}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          author: markupObj.author,
          action: 'Plan Review Redline Pin Dropped',
          details: `Correction on ${markupObj.sheet}: ${markupObj.comment}`,
        },
      ],
    };

    onUpdatePermit(updatedPermit);
  };

  // Resolve markup
  const handleResolveMarkup = (markupId: string) => {
    if (!selectedPermit) return;

    const updatedMarkups = selectedPermit.markups.map((m) =>
      m.id === markupId ? { ...m, status: 'resolved' as const } : m
    );

    onUpdatePermit({
      ...selectedPermit,
      markups: updatedMarkups,
    });
  };

  // Issue formal permit after review completion & payment
  const handleFinalPermitIssuance = () => {
    if (!selectedPermit) return;

    const updatedPermit: PermitApplication = {
      ...selectedPermit,
      status: 'issued',
      issuedDate: new Date().toISOString().split('T')[0],
      expirationDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      timeline: [
        ...selectedPermit.timeline,
        {
          id: `tl-issue-${Date.now()}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          author: 'David K. Miller, CBO',
          action: 'Official Permit Issued',
          details: 'All departmental approvals and fees verified. Construction authorized to proceed.',
        },
      ],
    };

    onUpdatePermit(updatedPermit);
  };

  const filteredPermits = permits.filter((p) => {
    const matchesSearch =
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.property.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.applicant.name.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (activeDeptFilter === 'all') return true;
    return p.departmentReviews.some((d) => d.department === activeDeptFilter);
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Back-Office Sub-Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="text-xs text-blue-600 font-semibold uppercase tracking-wider">
            City of Oakridge Community Development
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">
            Inter-Departmental Plan Review & Workflow Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Accela-grade municipal queue · Concurrent review routing across Zoning, Building, Fire & Public Works
          </p>
        </div>

        {/* Department Queue Selector tabs */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
          <button
            onClick={() => setActiveDeptFilter('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeDeptFilter === 'all' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Queues
          </button>
          <button
            onClick={() => setActiveDeptFilter('building')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeDeptFilter === 'building' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Building Safety
          </button>
          <button
            onClick={() => setActiveDeptFilter('zoning')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeDeptFilter === 'zoning' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Planning & Zoning
          </button>
          <button
            onClick={() => setActiveDeptFilter('fire')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeDeptFilter === 'fire' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Fire Marshal
          </button>
          <button
            onClick={() => setActiveDeptFilter('public_works')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeDeptFilter === 'public_works' ? 'bg-white text-slate-900 font-bold shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Public Works
          </button>
        </div>
      </div>

      {/* Main Grid: Queue Table on Left / Selected Permit Detail Drawer on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Queue Table (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-3">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by permit #, street, or contractor..."
              className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 shadow-sm"
            />
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm divide-y divide-slate-100">
            {filteredPermits.map((permit) => {
              const isSelected = permit.id === selectedPermit?.id;
              const isOverdue = permit.daysInReview > 14;
              const allDeptsApproved = permit.departmentReviews.every((d) => d.status === 'approved');

              return (
                <div
                  key={permit.id}
                  onClick={() => setActiveId(permit.id)}
                  className={`p-4 cursor-pointer transition-colors text-xs ${
                    isSelected
                      ? 'bg-blue-50/70 border-l-4 border-l-blue-600'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-slate-900">{permit.id}</span>
                    <span className="font-mono text-[11px] text-slate-500">
                      Day {permit.daysInReview} / 14 SLA
                    </span>
                  </div>

                  <div className="font-semibold text-slate-900 mt-1 line-clamp-1">
                    {permit.title}
                  </div>

                  <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                    {permit.property.address} · APN {permit.property.apn}
                  </div>

                  {/* Status Indicator text line without pill wrapping */}
                  <div className="mt-2 flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5 font-medium">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          permit.status === 'ready_for_payment' || permit.status === 'issued'
                            ? 'bg-emerald-500'
                            : permit.status === 'corrections_required'
                            ? 'bg-rose-500'
                            : 'bg-amber-500'
                        }`}
                      />
                      <span className="capitalize text-slate-700">
                        {permit.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="text-slate-500 font-mono">
                      {permit.departmentReviews.filter((d) => d.status === 'approved').length}/
                      {permit.departmentReviews.length} approved
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredPermits.length === 0 && (
              <div className="p-8 text-center text-xs text-slate-500">
                No active permits matching current filter.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Selected Permit Active Review Console (7 cols on lg) */}
        {selectedPermit ? (
          <div className="lg:col-span-7 space-y-6">
            {/* Header Card for Selected Permit */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 font-mono text-xs text-slate-500">
                    <span className="font-bold text-slate-900">{selectedPermit.id}</span>
                    <span>·</span>
                    <span className="capitalize font-sans">{selectedPermit.type.replace('_', ' ')}</span>
                    <span>·</span>
                    <span>Submitted {selectedPermit.submittedDate}</span>
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 mt-1">{selectedPermit.title}</h2>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {selectedPermit.property.address} (Zone {selectedPermit.property.zoning} · APN {selectedPermit.property.apn})
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {(selectedPermit.status === 'issued' || selectedPermit.status === 'inspections_active' || selectedPermit.status === 'final_approved') && (
                    <button
                      onClick={() => onViewCertificate(selectedPermit)}
                      className="px-3.5 py-1.5 text-xs font-semibold bg-slate-900 text-white hover:bg-slate-800 rounded transition-colors flex items-center gap-1.5"
                    >
                      <FileCheck className="w-3.5 h-3.5 text-blue-400" />
                      <span>Print Permit Certificate</span>
                    </button>
                  )}

                  {selectedPermit.status === 'ready_for_payment' && (
                    <button
                      onClick={handleFinalPermitIssuance}
                      className="px-4 py-1.5 text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 rounded transition-colors flex items-center gap-1.5 shadow-sm"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Issue Municipal Permit</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Scope & Valuation Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-slate-100 text-xs font-mono">
                <div>
                  <span className="text-slate-500 block text-[10px] font-sans">Valuation</span>
                  <strong className="text-slate-900">${selectedPermit.projectScope.estimatedValuation.toLocaleString()}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] font-sans">Floor Area</span>
                  <strong className="text-slate-900">{selectedPermit.projectScope.squareFootage} sq ft</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] font-sans">Occupancy</span>
                  <strong className="text-slate-900">{selectedPermit.projectScope.occupancyGroup}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] font-sans">Construction</span>
                  <strong className="text-slate-900">{selectedPermit.projectScope.constructionType}</strong>
                </div>
              </div>

              {/* Department Review Matrix */}
              <div className="pt-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Concurrent Department Review Matrix
                  </h3>
                  <span className="text-[11px] text-slate-500">All 4 departments must sign off prior to issuance</span>
                </div>

                <div className="space-y-3">
                  {selectedPermit.departmentReviews.map((review) => {
                    const isApproved = review.status === 'approved';
                    const isRevisions = review.status === 'revisions_requested';

                    return (
                      <div
                        key={review.department}
                        className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 text-xs space-y-2"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <div className="font-bold text-slate-900 text-xs">{review.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono">
                              Assigned: {review.reviewer} · Assigned {review.assignedDate}
                            </div>
                          </div>

                          {/* Action controls for this department */}
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-[10px] font-bold uppercase mr-2 ${
                                isApproved
                                  ? 'text-emerald-700'
                                  : isRevisions
                                  ? 'text-rose-700'
                                  : 'text-amber-700'
                              }`}
                            >
                              {review.status.replace('_', ' ')}
                            </span>

                            <button
                              onClick={() => handleDepartmentStatusChange(review.department, 'approved', 'Plans comply with code requirements.')}
                              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                                isApproved
                                  ? 'bg-emerald-600 text-white font-semibold'
                                  : 'bg-white border border-slate-300 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
                              }`}
                            >
                              Approve
                            </button>

                            <button
                              onClick={() => handleDepartmentStatusChange(review.department, 'revisions_requested', 'Revisions requested on submitted plan set.')}
                              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                                isRevisions
                                  ? 'bg-rose-600 text-white font-semibold'
                                  : 'bg-white border border-slate-300 text-slate-700 hover:bg-rose-50 hover:text-rose-800'
                              }`}
                            >
                              Request Revisions
                            </button>
                          </div>
                        </div>

                        {review.comments && (
                          <div className="p-2 bg-white rounded border border-slate-200 text-slate-700 text-[11px] italic">
                            "{review.comments}"
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Interactive Blueprint Plan Room Viewer */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Digital Plan Room & Redline Studio</h3>
                  <div className="text-xs text-slate-500">
                    Drop plan correction pins, cite building codes, and apply official city plan stamps
                  </div>
                </div>
              </div>

              <BlueprintViewer
                markups={selectedPermit.markups}
                onAddMarkup={handleAddMarkup}
                onResolveMarkup={handleResolveMarkup}
                onApplyStamp={(stamp) => {
                  onUpdatePermit({
                    ...selectedPermit,
                    timeline: [
                      ...selectedPermit.timeline,
                      {
                        id: `tl-st-${Date.now()}`,
                        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                        author: 'David K. Miller, CBO',
                        action: `Plan Stamp Applied: ${stamp}`,
                      },
                    ],
                  });
                }}
              />
            </div>

            {/* Municipal Fee Ledger */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Municipal Fee Ledger & Assessment
                </h3>
                <span className="text-xs font-mono font-bold text-slate-900">
                  Total: $
                  {selectedPermit.fees.reduce((acc, f) => acc + f.amount, 0).toFixed(2)}
                </span>
              </div>

              <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-200">
                    <tr>
                      <th className="py-2 px-3">Item Description</th>
                      <th className="py-2 px-3">Category</th>
                      <th className="py-2 px-3 text-right">Fee</th>
                      <th className="py-2 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {selectedPermit.fees.map((fee) => (
                      <tr key={fee.id} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-sans font-medium text-slate-800">{fee.name}</td>
                        <td className="py-2 px-3 text-slate-500 capitalize">{fee.category.replace('_', ' ')}</td>
                        <td className="py-2 px-3 text-right font-bold text-slate-900">${fee.amount.toFixed(2)}</td>
                        <td className="py-2 px-3 text-center">
                          {fee.status === 'paid' ? (
                            <span className="text-emerald-700 font-bold uppercase text-[10px]">PAID</span>
                          ) : (
                            <span className="text-amber-700 font-bold uppercase text-[10px]">PENDING</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Audit Trail Timeline */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Official Municipal Audit Trail
              </h3>
              <div className="space-y-3 pl-2 border-l-2 border-slate-200 text-xs">
                {selectedPermit.timeline.map((evt) => (
                  <div key={evt.id} className="relative pl-4">
                    <div className="w-2.5 h-2.5 rounded-full bg-blue-600 absolute -left-[21px] top-1" />
                    <div className="flex items-center justify-between text-slate-400 font-mono text-[10px]">
                      <span>{evt.timestamp}</span>
                      <span className="text-slate-600 font-sans font-medium">{evt.author}</span>
                    </div>
                    <div className="font-semibold text-slate-900 mt-0.5">{evt.action}</div>
                    {evt.details && <div className="text-slate-600 text-[11px] mt-0.5">{evt.details}</div>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
