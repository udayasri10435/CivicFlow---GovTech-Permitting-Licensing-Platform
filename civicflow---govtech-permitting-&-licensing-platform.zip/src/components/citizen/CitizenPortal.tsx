import React, { useState } from 'react';
import { PermitApplication, PermitType, InspectionRecord } from '../../types/permits';
import { MUNICIPAL_PARCELS, INSPECTION_TYPE_OPTIONS } from '../../data/mockMunicipalData';
import { 
  Building2, 
  FileCheck, 
  Clock, 
  AlertCircle, 
  CreditCard, 
  Calendar, 
  Search, 
  Upload, 
  Plus, 
  CheckCircle2, 
  ArrowRight, 
  FileText, 
  ChevronRight,
  ShieldCheck,
  HardHat,
  X,
  Eye
} from 'lucide-react';

interface CitizenPortalProps {
  permits: PermitApplication[];
  onAddNewPermit: (newPermit: PermitApplication) => void;
  onPayFees: (permitId: string) => void;
  onScheduleInspection: (inspection: Omit<InspectionRecord, 'id' | 'status'>) => void;
  onViewCertificate: (permit: PermitApplication) => void;
  onViewPlanReview: (permit: PermitApplication) => void;
  isWizardOpen: boolean;
  onCloseWizard: () => void;
  onOpenWizard: () => void;
}

export const CitizenPortal: React.FC<CitizenPortalProps> = ({
  permits,
  onAddNewPermit,
  onPayFees,
  onScheduleInspection,
  onViewCertificate,
  onViewPlanReview,
  isWizardOpen,
  onCloseWizard,
  onOpenWizard,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'under_review' | 'ready_for_payment' | 'issued'>('all');

  // Inspection Modal State
  const [inspectionTargetPermit, setInspectionTargetPermit] = useState<PermitApplication | null>(null);
  const [inspectionType, setInspectionType] = useState(INSPECTION_TYPE_OPTIONS[3]); // Framing
  const [inspectionDate, setInspectionDate] = useState('2026-10-02');
  const [inspectionTimeWindow, setInspectionTimeWindow] = useState<'AM (8:00 - 12:00)' | 'PM (12:00 - 4:00)'>('AM (8:00 - 12:00)');
  const [siteContactName, setSiteContactName] = useState('');
  const [siteContactPhone, setSiteContactPhone] = useState('');
  const [siteNotes, setSiteNotes] = useState('');

  // Payment Modal State
  const [paymentPermit, setPaymentPermit] = useState<PermitApplication | null>(null);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Application Wizard State
  const [step, setStep] = useState(1);
  const [formType, setFormType] = useState<PermitType>('adu_addition');
  const [formTitle, setFormTitle] = useState('');
  const [formAddress, setFormAddress] = useState(MUNICIPAL_PARCELS[0].address);
  const [formAPN, setFormAPN] = useState(MUNICIPAL_PARCELS[0].apn);
  const [formZoning, setFormZoning] = useState(MUNICIPAL_PARCELS[0].zoning);
  const [formLotSize, setFormLotSize] = useState(MUNICIPAL_PARCELS[0].lotSizeSqFt);
  const [formScopeDesc, setFormScopeDesc] = useState('');
  const [formSqFt, setFormSqFt] = useState<number>(650);
  const [formValuation, setFormValuation] = useState<number>(120000);
  const [formApplicantName, setFormApplicantName] = useState('Marcus Vance');
  const [formApplicantRole, setFormApplicantRole] = useState<'homeowner' | 'contractor'>('contractor');
  const [formContractorCompany, setFormContractorCompany] = useState('Highland Modern Builders LLC');
  const [formLicenseNum, setFormLicenseNum] = useState('CSLB-1049281-B');
  const [formPhone, setFormPhone] = useState('(555) 394-1120');
  const [formEmail, setFormEmail] = useState('m.vance@highlandbuilders.com');
  const [formUploadedFiles, setFormUploadedFiles] = useState<string[]>([
    'Site_Plan_Parcel_042_180_22.pdf',
    'Architectural_Floor_Plan_A1_A4.pdf',
    'Structural_Calculations_Stamped.pdf',
  ]);

  // Parcel change handler in wizard
  const handleSelectParcel = (apn: string) => {
    const p = MUNICIPAL_PARCELS.find((item) => item.apn === apn);
    if (p) {
      setFormAPN(p.apn);
      setFormAddress(p.address);
      setFormZoning(p.zoning);
      setFormLotSize(p.lotSizeSqFt);
    }
  };

  // Fee calculation formulas
  const calculateEstimatedFees = () => {
    const basePlanCheck = 450;
    const sqFtRate = formSqFt * 0.75;
    const valuationFee = Math.round(formValuation * 0.008);
    const techSurcharge = Math.round((basePlanCheck + sqFtRate + valuationFee) * 0.04);
    const total = basePlanCheck + sqFtRate + valuationFee + techSurcharge;
    return { basePlanCheck, sqFtRate, valuationFee, techSurcharge, total };
  };

  const handleCompleteApplication = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `PRMT-2026-0${Math.floor(850 + Math.random() * 100)}`;
    const feeCalc = calculateEstimatedFees();

    const newPermit: PermitApplication = {
      id: newId,
      type: formType,
      title: formTitle || `${formType.replace('_', ' ').toUpperCase()} at ${formAddress.split(',')[0]}`,
      applicant: {
        name: formApplicantName,
        role: formApplicantRole,
        company: formApplicantRole === 'contractor' ? formContractorCompany : undefined,
        licenseNumber: formApplicantRole === 'contractor' ? formLicenseNum : undefined,
        phone: formPhone,
        email: formEmail,
      },
      property: {
        address: formAddress,
        apn: formAPN,
        zoning: formZoning,
        lotSizeSqFt: formLotSize,
      },
      projectScope: {
        description: formScopeDesc || 'Proposed construction and alterations as detailed in submitted architectural plan set.',
        squareFootage: formSqFt,
        estimatedValuation: formValuation,
        stories: 1,
        occupancyGroup: 'R-3 Residential',
        constructionType: 'Type V-B Wood Frame',
      },
      status: 'under_review',
      submittedDate: new Date().toISOString().split('T')[0],
      targetCompletionDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      daysInReview: 0,
      departmentReviews: [
        {
          department: 'zoning',
          name: 'Planning & Zoning',
          reviewer: 'Elena Rodriguez, AICP',
          status: 'in_review',
          assignedDate: new Date().toISOString().split('T')[0],
        },
        {
          department: 'building',
          name: 'Building Safety Division',
          reviewer: 'David K. Miller, CBO',
          status: 'pending',
          assignedDate: new Date().toISOString().split('T')[0],
        },
        {
          department: 'fire',
          name: 'Oakridge Fire Protection District',
          reviewer: 'Capt. Thomas Hayes',
          status: 'pending',
          assignedDate: new Date().toISOString().split('T')[0],
        },
        {
          department: 'public_works',
          name: 'Public Works & Utilities',
          reviewer: 'Sarah Jenkins, PE',
          status: 'pending',
          assignedDate: new Date().toISOString().split('T')[0],
        },
      ],
      fees: [
        { id: `f-${Date.now()}-1`, name: 'Base Municipal Plan Check', category: 'plan_check', amount: feeCalc.basePlanCheck, status: 'paid', paidDate: new Date().toISOString().split('T')[0] },
        { id: `f-${Date.now()}-2`, name: 'Square Footage & Valuation Assessment', category: 'permit_fee', amount: feeCalc.sqFtRate + feeCalc.valuationFee, status: 'unpaid' },
        { id: `f-${Date.now()}-3`, name: 'Municipal Technology Surcharge (4%)', category: 'technology_surcharge', amount: feeCalc.techSurcharge, status: 'unpaid' },
      ],
      markups: [],
      inspections: [],
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: `${new Date().toISOString().split('T')[0]} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
          author: formApplicantName,
          action: 'Permit Application Submitted Online',
          details: 'Application initiated and initial plan check fee verified.',
        },
      ],
      documents: formUploadedFiles.map((name, idx) => ({
        id: `doc-new-${idx}`,
        name,
        type: idx === 0 ? 'site_plan' : idx === 1 ? 'architectural' : 'structural',
        size: '5.8 MB',
        uploadDate: new Date().toISOString().split('T')[0],
        version: 1,
      })),
    };

    onAddNewPermit(newPermit);
    onCloseWizard();
    setStep(1);
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inspectionTargetPermit) return;

    onScheduleInspection({
      permitId: inspectionTargetPermit.id,
      type: inspectionType,
      scheduledDate: inspectionDate,
      timeWindow: inspectionTimeWindow,
      inspectorName: 'Bob Martinez, ICC Certified',
      notes: siteNotes || 'Please call 15 minutes before arrival.',
      siteContact: {
        name: siteContactName || inspectionTargetPermit.applicant.name,
        phone: siteContactPhone || inspectionTargetPermit.applicant.phone,
      },
    });

    setInspectionTargetPermit(null);
    setSiteNotes('');
  };

  const handleProcessPayment = () => {
    if (!paymentPermit) return;
    setPaymentProcessing(true);
    setTimeout(() => {
      onPayFees(paymentPermit.id);
      setPaymentProcessing(false);
      setPaymentSuccess(true);
      setTimeout(() => {
        setPaymentSuccess(false);
        setPaymentPermit(null);
      }, 1500);
    }, 1200);
  };

  const filteredPermits = permits.filter((p) => {
    const matchesSearch =
      p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.property.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.title.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter === 'under_review') return p.status === 'under_review' || p.status === 'corrections_required';
    if (statusFilter === 'ready_for_payment') return p.status === 'ready_for_payment';
    if (statusFilter === 'issued') return p.status === 'issued' || p.status === 'inspections_active' || p.status === 'final_approved';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Citizen Welcome & Hero Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-8 shadow-sm mb-8">
        <div className="max-w-3xl">
          <div className="text-xs text-blue-600 font-semibold uppercase tracking-wider mb-2">
            City of Oakridge Citizen & Contractor Services
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Apply, track plan review, and manage municipal construction permits online.
          </h1>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            Welcome to the CivicFlow municipal portal. Submit architectural plans, check real-time zoning and building safety reviews, pay permit fees, and request field building inspections with instant SMS notifications.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenWizard}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shadow-sm flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Start New Permit Application</span>
            </button>
            <a
              href="#my-permits"
              className="px-4 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
            >
              View My Applications ({permits.length})
            </a>
          </div>
        </div>

        {/* Quick Civic Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-100 text-xs">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded bg-blue-50 text-blue-600">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900">14-Day Statutory Target</div>
              <div className="text-slate-500">Average residential first review cycle: 11.4 days</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="p-2 rounded bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900">Concurrent Department Routing</div>
              <div className="text-slate-500">Zoning, Building, Fire & Public Works review simultaneously</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="p-2 rounded bg-amber-50 text-amber-600">
              <HardHat className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900">Next-Day Inspections</div>
              <div className="text-slate-500">Book before 4:00 PM for guaranteed next-business-day route</div>
            </div>
          </div>
        </div>
      </div>

      {/* Applications Directory & Filter Section */}
      <div id="my-permits" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Permit & Project Directory</h2>
            <div className="text-xs text-slate-500">
              Track multi-department review status, correction letters, and scheduled inspections
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search permit #, address, or APN..."
                className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 w-64 focus:outline-none focus:border-blue-500 shadow-sm"
              />
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  statusFilter === 'all' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({permits.length})
              </button>
              <button
                onClick={() => setStatusFilter('under_review')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  statusFilter === 'under_review' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                In Review
              </button>
              <button
                onClick={() => setStatusFilter('ready_for_payment')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  statusFilter === 'ready_for_payment' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Ready for Fee Payment
              </button>
              <button
                onClick={() => setStatusFilter('issued')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  statusFilter === 'issued' ? 'bg-white text-slate-900 font-semibold shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Issued & Active
              </button>
            </div>
          </div>
        </div>

        {/* Permit Cards List */}
        <div className="grid grid-cols-1 gap-4">
          {filteredPermits.map((permit) => {
            const unpaidFees = permit.fees.filter((f) => f.status === 'unpaid');
            const totalUnpaid = unpaidFees.reduce((acc, f) => acc + f.amount, 0);
            const approvedDepts = permit.departmentReviews.filter((d) => d.status === 'approved').length;
            const totalDepts = permit.departmentReviews.length;

            return (
              <div
                key={permit.id}
                className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm hover:border-slate-300 transition-colors"
              >
                {/* Header metadata row */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    {/* Zero-Pill Metadata rule: Unboxed text separated by dots */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono">
                      <span className="font-bold text-slate-900">{permit.id}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize font-sans font-medium text-slate-700">
                        {permit.type.replace('_', ' ')}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Filed {permit.submittedDate}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-sans font-semibold text-blue-700">
                        {permit.status.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 mt-1">{permit.title}</h3>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {permit.property.address} <span className="text-slate-400">·</span> APN: {permit.property.apn} (Zone {permit.property.zoning})
                    </div>
                  </div>

                  {/* Actions according to permit state */}
                  <div className="flex items-center gap-2 shrink-0 mt-2 sm:mt-0">
                    <button
                      onClick={() => onViewPlanReview(permit)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors flex items-center gap-1.5"
                      title="Inspect architectural plans and department redline comments"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-600" />
                      <span>View Plan Room</span>
                    </button>

                    {permit.status === 'ready_for_payment' && totalUnpaid > 0 && (
                      <button
                        onClick={() => setPaymentPermit(permit)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded transition-colors flex items-center gap-1.5 shadow-sm"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Pay ${totalUnpaid.toLocaleString()} Fees</span>
                      </button>
                    )}

                    {(permit.status === 'issued' || permit.status === 'inspections_active' || permit.status === 'final_approved') && (
                      <>
                        <button
                          onClick={() => onViewCertificate(permit)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded transition-colors flex items-center gap-1.5"
                        >
                          <FileCheck className="w-3.5 h-3.5 text-blue-600" />
                          <span>Official Permit</span>
                        </button>
                        {permit.status !== 'final_approved' && (
                          <button
                            onClick={() => {
                              setInspectionTargetPermit(permit);
                              setSiteContactName(permit.applicant.name);
                              setSiteContactPhone(permit.applicant.phone);
                            }}
                            className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors flex items-center gap-1.5 shadow-sm"
                          >
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Schedule Inspection</span>
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Multi-department progress bar */}
                <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-3">
                  {permit.departmentReviews.map((dept) => {
                    const isApproved = dept.status === 'approved';
                    const isRevisions = dept.status === 'revisions_requested';
                    const isInReview = dept.status === 'in_review';

                    return (
                      <div
                        key={dept.department}
                        className={`p-3 rounded-lg border text-xs ${
                          isApproved
                            ? 'bg-emerald-50/50 border-emerald-200 text-slate-800'
                            : isRevisions
                            ? 'bg-rose-50/60 border-rose-200 text-slate-800'
                            : isInReview
                            ? 'bg-blue-50/50 border-blue-200 text-slate-800'
                            : 'bg-slate-50 border-slate-200 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold mb-1">
                          <span>{dept.name}</span>
                          <span
                            className={`text-[10px] uppercase font-bold ${
                              isApproved
                                ? 'text-emerald-700'
                                : isRevisions
                                ? 'text-rose-700'
                                : isInReview
                                ? 'text-blue-700'
                                : 'text-slate-500'
                            }`}
                          >
                            {dept.status.replace('_', ' ')}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600 truncate">{dept.reviewer}</div>
                        {dept.comments && (
                          <div className="mt-1 text-[11px] text-slate-700 line-clamp-2 italic">
                            "{dept.comments}"
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Inspections Summary Row if active */}
                {permit.inspections.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <HardHat className="w-4 h-4 text-blue-600" />
                      <span className="font-semibold text-slate-800">Field Inspections:</span>
                      <span className="text-slate-600">
                        {permit.inspections.filter((i) => i.status === 'passed').length} passed · {permit.inspections.filter((i) => i.status === 'scheduled').length} scheduled
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {permit.inspections.map((insp) => (
                        <div
                          key={insp.id}
                          className="px-2 py-1 rounded bg-slate-100 text-slate-700 text-[11px] font-mono flex items-center gap-1.5"
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              insp.status === 'passed' ? 'bg-emerald-500' : 'bg-blue-500 animate-pulse'
                            }`}
                          />
                          <span>{insp.type}</span>
                          <span className="text-slate-400">({insp.scheduledDate})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {filteredPermits.length === 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-800">No permits found</h3>
              <p className="text-xs text-slate-500 mt-1">Try adjusting your search criteria or start a new application.</p>
            </div>
          )}
        </div>
      </div>

      {/* 5-Step Application Wizard Modal */}
      {isWizardOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-3xl w-full my-8 overflow-hidden">
            {/* Wizard Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-blue-400 font-semibold uppercase tracking-wider">
                  City of Oakridge Permitting Division
                </div>
                <h2 className="text-lg font-bold">New Permit Application Wizard</h2>
              </div>
              <button onClick={onCloseWizard} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper tabs */}
            <div className="bg-slate-100 px-6 py-3 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600 font-medium">
              {[
                { s: 1, title: 'Classification' },
                { s: 2, title: 'Parcel & GIS' },
                { s: 3, title: 'Scope & Scope' },
                { s: 4, title: 'Plan Upload' },
                { s: 5, title: 'Fees & Submit' },
              ].map((item) => (
                <div key={item.s} className="flex items-center gap-1.5">
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      step === item.s
                        ? 'bg-blue-600 text-white'
                        : step > item.s
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {step > item.s ? '✓' : item.s}
                  </span>
                  <span className={`hidden sm:inline ${step === item.s ? 'text-slate-900 font-bold' : ''}`}>
                    {item.title}
                  </span>
                </div>
              ))}
            </div>

            {/* Step Body */}
            <div className="p-6">
              {step === 1 && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Select Permit Classification</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {[
                      { type: 'adu_addition', title: 'Accessory Dwelling Unit (ADU)', desc: 'Detached or attached secondary dwelling units with kitchen/bath' },
                      { type: 'residential_alteration', title: 'Residential Addition & Remodel', desc: 'Room additions, interior wall alterations, kitchen/bath renovations' },
                      { type: 'commercial_ti', title: 'Commercial Tenant Improvement', desc: 'Interior retail, restaurant, medical office, or corporate build-outs' },
                      { type: 'solar_pv_storage', title: 'Solar PV & Battery Storage', desc: 'Rooftop residential/commercial solar arrays and ESS Powerwalls' },
                      { type: 'electrical_service', title: 'Main Electrical Panel Upgrade', desc: '200A service upgrades, EV charging stations, subpanels' },
                      { type: 'right_of_way', title: 'Right-of-Way Encroachment', desc: 'Curb cuts, sidewalk repair, street utility trenching' },
                    ].map((opt) => (
                      <div
                        key={opt.type}
                        onClick={() => setFormType(opt.type as PermitType)}
                        className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                          formType === opt.type
                            ? 'border-blue-600 bg-blue-50/40 text-blue-950 ring-1 ring-blue-600'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="font-bold text-sm text-slate-900">{opt.title}</div>
                        <div className="text-slate-600 mt-1">{opt.desc}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4">
                    <label className="block text-xs font-semibold text-slate-800 mb-1">Project Working Title</label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="e.g. 750 Sq Ft Detached 2-Bedroom ADU"
                      className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Project Location & Parcel GIS Lookup</h3>
                  <p className="text-xs text-slate-600">
                    Select a municipal tax parcel to auto-verify City of Oakridge zoning, setbacks, and flood hazard designations.
                  </p>

                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-800">Select Parcel by Address or APN</label>
                    <select
                      value={formAPN}
                      onChange={(e) => handleSelectParcel(e.target.value)}
                      className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600 bg-white"
                    >
                      {MUNICIPAL_PARCELS.map((p) => (
                        <option key={p.apn} value={p.apn}>
                          {p.address} (APN: {p.apn} · {p.zoning})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
                    <div>
                      <span className="text-slate-500 block text-[10px] font-sans">APN Number</span>
                      <strong className="text-slate-900">{formAPN}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px] font-sans">Zoning Classification</span>
                      <strong className="text-slate-900">{formZoning}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px] font-sans">Lot Dimensions</span>
                      <strong className="text-slate-900">{formLotSize.toLocaleString()} sq ft</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px] font-sans">FEMA Flood Zone</span>
                      <strong className="text-slate-900">Zone X (Minimal)</strong>
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Project Scope & Permittee Information</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-800 mb-1">Declared Project Valuation ($ USD)</label>
                      <input
                        type="number"
                        value={formValuation}
                        onChange={(e) => setFormValuation(Number(e.target.value))}
                        className="w-full p-2.5 border border-slate-300 rounded-lg font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-800 mb-1">New or Altered Floor Area (Sq Ft)</label>
                      <input
                        type="number"
                        value={formSqFt}
                        onChange={(e) => setFormSqFt(Number(e.target.value))}
                        className="w-full p-2.5 border border-slate-300 rounded-lg font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-800 mb-1">Detailed Description of Work</label>
                    <textarea
                      rows={3}
                      value={formScopeDesc}
                      onChange={(e) => setFormScopeDesc(e.target.value)}
                      placeholder="Construction of new wood-frame detached accessory dwelling unit with 2 bedrooms, kitchen, 1 ADA-compliant bath, mini-split HVAC..."
                      className="w-full text-xs p-2.5 border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div className="pt-2 border-t border-slate-200">
                    <div className="text-xs font-semibold text-slate-800 mb-2">Permittee / Contractor Details</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-slate-600 mb-0.5">Applicant Name</label>
                        <input
                          type="text"
                          value={formApplicantName}
                          onChange={(e) => setFormApplicantName(e.target.value)}
                          className="w-full p-2 border border-slate-300 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">Contractor Company (if applicable)</label>
                        <input
                          type="text"
                          value={formContractorCompany}
                          onChange={(e) => setFormContractorCompany(e.target.value)}
                          className="w-full p-2 border border-slate-300 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">State Contractor License #</label>
                        <input
                          type="text"
                          value={formLicenseNum}
                          onChange={(e) => setFormLicenseNum(e.target.value)}
                          className="w-full p-2 border border-slate-300 rounded font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">Direct Phone</label>
                        <input
                          type="text"
                          value={formPhone}
                          onChange={(e) => setFormPhone(e.target.value)}
                          className="w-full p-2 border border-slate-300 rounded font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Digital Plan Room & Plan Set Intake</h3>
                  <p className="text-xs text-slate-600">
                    Upload architectural blueprints, structural engineering calculations, and energy compliance documentation (Title 24).
                  </p>

                  <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center bg-slate-50">
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <div className="text-xs font-semibold text-slate-800">
                      Drag & drop PDF plan sheets here or click to browse
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      Max file size 50 MB per sheet. Vector PDF format preferred for plan markup.
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-slate-800">Uploaded Plan Sheets ({formUploadedFiles.length})</div>
                    {formUploadedFiles.map((file, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-2.5 bg-slate-100 rounded border border-slate-200 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-blue-600" />
                          <span className="font-mono text-slate-800">{file}</span>
                        </div>
                        <span className="text-[10px] text-emerald-700 font-bold uppercase">Ready for Plan Check</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {step === 5 && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Municipal Fee Ledger & Submission Verification</h3>
                  <p className="text-xs text-slate-600">
                    Initial plan check fees are calculated automatically per Oakridge Master Fee Schedule. Permit issuance and impact fees become due upon final plan approval.
                  </p>

                  {(() => {
                    const feeCalc = calculateEstimatedFees();
                    return (
                      <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                        <table className="w-full text-left">
                          <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                            <tr>
                              <th className="py-2 px-3">Municipal Fee Description</th>
                              <th className="py-2 px-3">Basis</th>
                              <th className="py-2 px-3 text-right">Amount</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                            <tr>
                              <td className="py-2 px-3 font-sans">Base Plan Check Review Fee</td>
                              <td className="py-2 px-3 text-slate-500 font-sans">Oakridge Master Schedule</td>
                              <td className="py-2 px-3 text-right font-bold">${feeCalc.basePlanCheck.toFixed(2)}</td>
                            </tr>
                            <tr>
                              <td className="py-2 px-3 font-sans">Area Plan Review Surcharge</td>
                              <td className="py-2 px-3 text-slate-500 font-sans">{formSqFt} sq ft @ $0.75/sq ft</td>
                              <td className="py-2 px-3 text-right font-bold">${feeCalc.sqFtRate.toFixed(2)}</td>
                            </tr>
                            <tr>
                              <td className="py-2 px-3 font-sans">Valuation Assessment</td>
                              <td className="py-2 px-3 text-slate-500 font-sans">${formValuation.toLocaleString()} valuation</td>
                              <td className="py-2 px-3 text-right font-bold">${feeCalc.valuationFee.toFixed(2)}</td>
                            </tr>
                            <tr>
                              <td className="py-2 px-3 font-sans">Municipal Technology Surcharge (4%)</td>
                              <td className="py-2 px-3 text-slate-500 font-sans">OMC Title 3</td>
                              <td className="py-2 px-3 text-right font-bold">${feeCalc.techSurcharge.toFixed(2)}</td>
                            </tr>
                            <tr className="bg-slate-50 font-bold text-slate-900 font-sans text-xs">
                              <td colSpan={2} className="py-2.5 px-3">Total Estimated Permit Fees</td>
                              <td className="py-2.5 px-3 text-right font-mono text-blue-700">${feeCalc.total.toFixed(2)}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    );
                  })()}

                  <div className="p-3 bg-amber-50 rounded border border-amber-200 text-xs text-amber-900">
                    <strong>Submission Declaration:</strong> By submitting, the applicant certifies that all project information is true and correct, and agrees to comply with the City of Oakridge Municipal Code and California Building Standards (Title 24).
                  </div>
                </div>
              )}
            </div>

            {/* Stepper Footer Controls */}
            <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="px-4 py-2 border border-slate-300 rounded font-medium text-slate-700 hover:bg-slate-100"
                >
                  Previous Step
                </button>
              ) : (
                <div />
              )}

              {step < 5 ? (
                <button
                  type="button"
                  onClick={() => setStep(step + 1)}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded shadow-sm flex items-center gap-1.5"
                >
                  <span>Continue</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleCompleteApplication}
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded shadow-sm flex items-center gap-1.5"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Submit Application to City</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Schedule Inspection Modal */}
      {inspectionTargetPermit && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold">Schedule Building Inspection</h3>
              </div>
              <button onClick={() => setInspectionTargetPermit(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBookingSubmit} className="mt-4 space-y-4 text-xs">
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <div className="font-semibold text-slate-900">{inspectionTargetPermit.id}</div>
                <div className="text-slate-600">{inspectionTargetPermit.property.address}</div>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Inspection Discipline & Phase</label>
                <select
                  value={inspectionType}
                  onChange={(e) => setInspectionType(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded bg-white font-medium"
                >
                  {INSPECTION_TYPE_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">Requested Date</label>
                  <input
                    type="date"
                    required
                    value={inspectionDate}
                    onChange={(e) => setInspectionDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">Time Window</label>
                  <select
                    value={inspectionTimeWindow}
                    onChange={(e) => setInspectionTimeWindow(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded bg-white"
                  >
                    <option value="AM (8:00 - 12:00)">AM (8:00 - 12:00)</option>
                    <option value="PM (12:00 - 4:00)">PM (12:00 - 4:00)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">On-Site Contact Name</label>
                  <input
                    type="text"
                    required
                    value={siteContactName}
                    onChange={(e) => setSiteContactName(e.target.value)}
                    placeholder="Foreman or Homeowner"
                    className="w-full p-2 border border-slate-300 rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">SMS Alert Mobile Phone</label>
                  <input
                    type="text"
                    required
                    value={siteContactPhone}
                    onChange={(e) => setSiteContactPhone(e.target.value)}
                    placeholder="(555) 000-0000"
                    className="w-full p-2 border border-slate-300 rounded font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Site Access / Lockbox Instructions</label>
                <textarea
                  rows={2}
                  value={siteNotes}
                  onChange={(e) => setSiteNotes(e.target.value)}
                  placeholder="Gate code 4821, dog in backyard will be secured in garage..."
                  className="w-full p-2 border border-slate-300 rounded"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setInspectionTargetPermit(null)}
                  className="px-4 py-2 border border-slate-300 rounded text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded shadow-sm"
                >
                  Confirm & Dispatch Inspection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Online Payment Modal */}
      {paymentPermit && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold">Municipal Fee Checkout</h3>
              </div>
              <button onClick={() => setPaymentPermit(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {paymentSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-slate-900">Payment Processed Successfully!</h4>
                <p className="text-xs text-slate-600">
                  Permit <span className="font-mono font-bold">{paymentPermit.id}</span> is now formally <strong>ISSUED</strong>. Official permit certificate and job card have been generated.
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-4 text-xs">
                <div className="p-3 bg-slate-50 rounded border border-slate-200">
                  <div className="font-semibold text-slate-900">{paymentPermit.id}</div>
                  <div className="text-slate-600">{paymentPermit.title}</div>
                </div>

                <div className="space-y-1.5 border border-slate-200 rounded p-3">
                  <div className="font-semibold text-slate-800 pb-1 border-b border-slate-100">
                    Outstanding Municipal Fees
                  </div>
                  {paymentPermit.fees
                    .filter((f) => f.status === 'unpaid')
                    .map((f) => (
                      <div key={f.id} className="flex justify-between py-1 text-slate-700 font-mono text-[11px]">
                        <span className="font-sans">{f.name}</span>
                        <span>${f.amount.toFixed(2)}</span>
                      </div>
                    ))}
                  <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900 text-xs">
                    <span>Total Amount Due</span>
                    <span className="font-mono text-emerald-700">
                      $
                      {paymentPermit.fees
                        .filter((f) => f.status === 'unpaid')
                        .reduce((a, b) => a + b.amount, 0)
                        .toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block font-semibold text-slate-800">Simulated Payment Method</label>
                  <div className="p-3 border border-blue-500 bg-blue-50/50 rounded flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">City of Oakridge Municipal Pay</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-500">•••• 4242</span>
                  </div>
                </div>

                <button
                  onClick={handleProcessPayment}
                  disabled={paymentProcessing}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded shadow transition-colors flex items-center justify-center gap-2"
                >
                  {paymentProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Authorizing Municipal Transaction...</span>
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4" />
                      <span>
                        Authorize Payment & Issue Permit ($
                        {paymentPermit.fees
                          .filter((f) => f.status === 'unpaid')
                          .reduce((a, b) => a + b.amount, 0)
                          .toFixed(2)}
                        )
                      </span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
